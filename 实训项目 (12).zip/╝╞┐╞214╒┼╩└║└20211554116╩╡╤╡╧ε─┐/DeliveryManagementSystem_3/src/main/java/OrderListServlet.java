package main.java;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@WebServlet("/OrderListServlet")
public class OrderListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取订单列表
        OrderDAO orderDAO = new OrderDAO();
        List<Order> orderList = orderDAO.selectOrder(null, null, null, null, null);

        // 将订单列表存入请求对象中
        request.setAttribute("orderList", orderList);

        // 请求转发至订单列表页面
        request.getRequestDispatcher("/search.jsp").forward(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        // 获取客户端提交的查询条件
        String userId = request.getParameter("userId"); // 用户编号
        String userName = request.getParameter("userName"); // 用户姓名
        String contact = request.getParameter("contact"); // 联系方式
        String orderId = request.getParameter("orderId"); // 订单号
        String status = request.getParameter("status"); // 配送状态

        // 调用 OrderDAO 查找订单
        OrderDAO orderDAO = new OrderDAO();
        List<Order> OrderList = orderDAO.selectOrder(userId, userName, contact, orderId, status);

        // 将订单列表存入请求对象中
        request.setAttribute("OrderList", OrderList);

        // 请求转发至订单列表页面
        request.getRequestDispatcher("/OrderList.jsp").forward(request, response);
    }
}