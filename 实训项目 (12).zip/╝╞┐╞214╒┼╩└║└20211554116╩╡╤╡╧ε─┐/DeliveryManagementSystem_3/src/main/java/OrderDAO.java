package main.java;

import com.alibaba.druid.util.StringUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    // 添加订单信息到数据库中
    public int insertOrder(Order order) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            // 获取数据库连接
            conn = DBUtil.getConnection();

            // 构建插入语句
            String sql = "INSERT INTO order_info(user_id, user_name, order_id, paid, address, status, price, contact) " +
                    "VALUES(?,?,?,?,?,?,?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, order.getUserID());
            pstmt.setString(2, order.getUserName());
            pstmt.setString(3, order.getOrderID());
            pstmt.setString(4, order.getPaid());
            pstmt.setString(5, order.getAddress());
            pstmt.setString(6, order.getStatus());
            pstmt.setString(7, order.getPrice());
            pstmt.setString(8, order.getContact());

            // 执行插入操作
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeConnection(conn, pstmt, null);
        }

        return result;
    }

    // 根据条件查询订单信息
    public List<Order> selectOrder(String userID, String userName, String contact, String orderID, String status) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Order> orderList = new ArrayList<>();

        try {
            // 获取数据库连接
            conn = DBUtil.getConnection();

            // 构建查询语句
            StringBuilder sql = new StringBuilder("SELECT * FROM order_info WHERE 1 = 1");
            if (!StringUtils.isEmpty(userID)) {
                sql.append(" AND user_id = ?");
            }
            if (!StringUtils.isEmpty(userName)) {
                sql.append(" AND user_name = ?");
            }
            if (!StringUtils.isEmpty(contact)) {
                sql.append(" AND contact = ?");
            }
            if (!StringUtils.isEmpty(orderID)) {
                sql.append(" AND order_id = ?");
            }
            if (!StringUtils.isEmpty(status)) {
                sql.append(" AND status = ?");
            }
            pstmt = conn.prepareStatement(sql.toString());

            // 设置条件参数
            int index = 1;
            if (!StringUtils.isEmpty(userID)) {
                pstmt.setString(index++, userID);
            }
            if (!StringUtils.isEmpty(userName)) {
                pstmt.setString(index++, userName);
            }
            if (!StringUtils.isEmpty(contact)) {
                pstmt.setString(index++, contact);
            }
            if (!StringUtils.isEmpty(orderID)) {
                pstmt.setString(index++, orderID);
            }
            if (!StringUtils.isEmpty(status)) {
                pstmt.setString(index, status);
            }

            // 执行查询操作
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setUserID(rs.getString("user_id"));
                order.setUserName(rs.getString("user_name"));
                order.setOrderID(rs.getString("order_id"));
                order.setPaid(rs.getString("paid"));
                order.setAddress(rs.getString("address"));
                order.setStatus(rs.getString("status"));
                order.setPrice(rs.getString("price"));
                order.setContact(rs.getString("contact"));

                orderList.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeConnection(conn, pstmt, rs);
        }

        return orderList;
    }

    // 根据订单号删除订单信息
    public int deleteOrder(String orderID) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            // 获取数据库连接
            conn = DBUtil.getConnection();

            // 构建删除语句
            String sql = "DELETE FROM order_info WHERE order_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, orderID);

            // 执行删除操作
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeConnection(conn, pstmt, null);
        }

        return result;
    }

    // 根据订单号修改订单信息
    public int updateOrder(Order order) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            // 获取数据库连接
            conn = DBUtil.getConnection();

            // 构建更新语句
            String sql = "UPDATE order_info SET user_id = ?, user_name = ?, paid = ?, address = ?, " +
                    "status = ?, price =?, contact = ? WHERE order_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, order.getUserID());
            pstmt.setString(2, order.getUserName());
            pstmt.setString(3, order.getPaid());
            pstmt.setString(4, order.getAddress());
            pstmt.setString(5, order.getStatus());
            pstmt.setString(6, order.getPrice());
            pstmt.setString(7, order.getContact());
            pstmt.setString(8, order.getOrderID());
            // 执行更新操作
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeConnection(conn, pstmt, null);
        }

        return result;
    }
}