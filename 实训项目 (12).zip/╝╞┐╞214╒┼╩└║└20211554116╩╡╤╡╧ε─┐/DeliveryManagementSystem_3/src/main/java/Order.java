package main.java;
public class Order {
    private String UserID;

    public Order(String userID, String userName, String orderID, String paid, String address, String status, String price, String contact) {
        UserID = userID;
        UserName = userName;
        OrderID = orderID;
        Paid = paid;
        Address = address;
        Status = status;
        Price = price;
        Contact = contact;
    }

    public Order() {

    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String orderID) {
        OrderID = orderID;
    }

    public String getPaid() {
        return Paid;
    }

    public void setPaid(String paid) {
        Paid = paid;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getContact() {
        return Contact;
    }

    public void setContact(String contact) {
        Contact = contact;
    }

    private String UserName;
    private String OrderID;
    private String Paid;
    private String Address;
    private String Status;
    private String Price;
    private String Contact;

}
