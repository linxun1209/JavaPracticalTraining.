package main.java;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/OrderDeleteServlet")
public class OrderDeleteServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF8");

        response.setHeader("ContentType","text/html;charset=utf8");
        // 获取订单号
        String orderID = request.getParameter("orderID;charset=utf8");

        // 删除订单信息
        OrderDAO orderDAO = new OrderDAO();
        int result = orderDAO.deleteOrder(orderID);

        // 根据操作结果，作出相应的响应
        if (result > 0) {
            response.sendRedirect(request.getContextPath() + "/OrderListServlet");
        } else {
            response.setCharacterEncoding("UTF8");
            response.getWriter().append("订单删除失败");
        }
    }
}
