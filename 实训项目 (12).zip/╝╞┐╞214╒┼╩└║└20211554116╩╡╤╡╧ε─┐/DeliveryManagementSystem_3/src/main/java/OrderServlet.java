package main.java;
import main.java.OrderDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 获取前端表单提交的数据
        request.setCharacterEncoding("utf-8");
        String userID = request.getParameter("userID");
        String userName = request.getParameter("userName");
        String orderID = request.getParameter("orderID");
        String paid = request.getParameter("paid");
        String address = request.getParameter("address");
        String status = request.getParameter("status");
        String price = request.getParameter("price");
        String contact = request.getParameter("contact");

        // 创建订单对象
        Order order = new Order(userID, userName, orderID, paid, address, status, price, contact);

        // 调用DAO类中的方法，将订单信息存入数据库中
        OrderDAO orderDAO = new OrderDAO();
        int result = orderDAO.insertOrder(order);

        // 判断是否存入成功，并做出相应的响应
        if (result == 1) {
            response.getWriter().println("<script>alert('添加成功！');window.location.href='index.jsp'</script>");
        } else {
            response.getWriter().println("<script>alert('添加失败！');window.location.href='index.jsp'</script>");
        }
    }
}