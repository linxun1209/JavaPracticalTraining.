package main.java;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/OrderEditServlet")
public class OrderEditServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取订单号
        String orderID = request.getParameter("orderID;charset=utf8");

        // 根据订单号查询订单信息
        OrderDAO orderDAO = new OrderDAO();
        List<Order> orderList = orderDAO.selectOrder(null, null, null, orderID, null);

        // 将订单信息存入请求对象中
        request.setAttribute("order", orderList.get(0));

        // 请求转发至订单编辑页面
        request.getRequestDispatcher("/OrderEdit.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("UTF8");
        response.setHeader("ContentType","text/html;charset=utf8");
        request.setCharacterEncoding("UTF8");
        // 获取表单提交的订单信息
        String userID = request.getParameter("userID");
        String userName = request.getParameter("userName");
        String orderID = request.getParameter("orderID");
        String paid = request.getParameter("paid");
        String address = request.getParameter("address");
        String status = request.getParameter("status");
        String price = request.getParameter("price");
        String contact = request.getParameter("contact");

        // 创建 Order 对象，并设置订单信息
        Order order = new Order();
        order.setUserID(userID);
        order.setUserName(userName);
        order.setOrderID(orderID);
        order.setPaid(paid);
        order.setAddress(address);
        order.setStatus(status);
        order.setPrice(price);
        order.setContact(contact);

        // 更新订单信息
        OrderDAO orderDAO = new OrderDAO();
        int result = orderDAO.updateOrder(order);

        // 根据操作结果，作出相应的响应
        if (result > 0) {
            response.sendRedirect(request.getContextPath() + "/OrderListServlet");
        } else {
            response.getWriter().append("订单修改失败");
        }
    }
}

//@WebServlet("/OrderDeleteServlet")
//    class OrderDeleteServlet extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//}