/*
 Navicat Premium Data Transfer

 Source Server         : lll
 Source Server Type    : MySQL
 Source Server Version : 80033
 Source Host           : localhost:3306
 Source Schema         : lsms_db

 Target Server Type    : MySQL
 Target Server Version : 80033
 File Encoding         : 65001

 Date: 09/06/2023 10:17:13
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `admin_id` int(0) NOT NULL,
  `admin_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `admin_phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `admin_password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`admin_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'Admin233', '19965583122', '123456');
INSERT INTO `admin` VALUES (2, '1', '10000', '1');
INSERT INTO `admin` VALUES (3, 'wly', '13592217102', '325');

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`  (
  `book_id` int(0) NOT NULL,
  `book_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `book_writer` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `book_publish` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `book_amount` int(0) NOT NULL,
  `book_price` double NOT NULL,
  `book_discount` double NOT NULL DEFAULT 1,
  PRIMARY KEY (`book_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES (1, '计算机网络', '谢希仁', '电子工业出版社', 95, 59.8, 1);
INSERT INTO `book` VALUES (2, '计算机组成与系统结构', '袁春风', '清华大学出版社', 95, 59.5, 1);
INSERT INTO `book` VALUES (3, '设计模式(第2版)', '刘伟', '清华大学出版社', 100, 79.8, 1);
INSERT INTO `book` VALUES (4, '设计模式实训教程（第2版）', '刘伟', '清华大学出版社', 100, 59, 1);
INSERT INTO `book` VALUES (5, '鸟哥的Linux私房菜', '鸟哥', '机械工业出版社', 150, 19.9, 1);
INSERT INTO `book` VALUES (6, 'MySQL必知必会', '刘晓霞', '人民邮电出版社', 100, 9.9, 1);
INSERT INTO `book` VALUES (8, '西游记', '西游出版社', '吴承恩', 60, 59, 1);
INSERT INTO `book` VALUES (9, '爱格', '大地出版社', '一只兔子', 50, 18, 0.9);

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `order_id` int(0) NOT NULL AUTO_INCREMENT,
  `order_price` double NOT NULL,
  `order_total` double NOT NULL,
  `order_amount` int(0) NOT NULL,
  `order_remark` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `order_book_id` int(0) NOT NULL,
  `order_reader_id` int(0) NOT NULL,
  PRIMARY KEY (`order_id`) USING BTREE,
  INDEX `order_book_id`(`order_book_id`) USING BTREE,
  INDEX `order_reader_id`(`order_reader_id`) USING BTREE,
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`order_book_id`) REFERENCES `book` (`book_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`order_reader_id`) REFERENCES `reader` (`reader_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES (1, 59.8, 59.8, 1, '无备注', 1, 1);
INSERT INTO `order` VALUES (2, 59.5, 119, 2, '无备注', 2, 1);
INSERT INTO `order` VALUES (3, 59.5, 178.5, 3, '无备注', 2, 1);

-- ----------------------------
-- Table structure for reader
-- ----------------------------
DROP TABLE IF EXISTS `reader`;
CREATE TABLE `reader`  (
  `reader_id` int(0) NOT NULL,
  `reader_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `reader_phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `reader_password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`reader_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reader
-- ----------------------------
INSERT INTO `reader` VALUES (1, '123', '10086', '123');
INSERT INTO `reader` VALUES (2, 'wly', '18866661234', '125');
INSERT INTO `reader` VALUES (3, 'xzd', '18155667788', 'qwertyuiop');
INSERT INTO `reader` VALUES (4, 'xxxx', '15936971642', '001128');
INSERT INTO `reader` VALUES (5, 'wly', '15936971642', '001128');
INSERT INTO `reader` VALUES (6, 'aaaa', '1111111111', '111111');
INSERT INTO `reader` VALUES (7, 'xem', '18763659547', '9045');

SET FOREIGN_KEY_CHECKS = 1;
