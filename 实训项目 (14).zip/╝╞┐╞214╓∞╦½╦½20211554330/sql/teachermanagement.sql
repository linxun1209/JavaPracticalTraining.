/*
 Navicat Premium Data Transfer

 Source Server         : test
 Source Server Type    : MySQL
 Source Server Version : 50719
 Source Host           : localhost:3306
 Source Schema         : teachermanagement

 Target Server Type    : MySQL
 Target Server Version : 50719
 File Encoding         : 65001

 Date: 09/06/2023 10:49:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for apply
-- ----------------------------
DROP TABLE IF EXISTS `apply`;
CREATE TABLE `apply`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicant` varchar(110) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `create_time` datetime(0) DEFAULT NULL,
  `apply_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `sex` varchar(110) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(110) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `zhuanye` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `xueli` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `schoolname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `zhicheng` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `riqi` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of apply
-- ----------------------------
INSERT INTO `apply` VALUES (29, '张三', '2023-06-07 02:43:04', NULL, '河南科技学院', 0, '男', '数学学院', '1', NULL, '数学', '本科', '', '三级', '2001-12-02');
INSERT INTO `apply` VALUES (30, '李四', '2023-06-07 02:43:48', NULL, '河南大学', 0, '男', '信息工程学院', '2', NULL, '物联网', '硕士', '', '二级', '2010-09-08');
INSERT INTO `apply` VALUES (31, '王五', '2023-06-07 02:44:56', NULL, '河南师范大学', 0, '男', '外国语学院', '3', NULL, '英语', '本科', '', '三级', '2020-12-11');
INSERT INTO `apply` VALUES (32, '李梅', '2023-06-07 02:54:58', NULL, '河南中医药大学', 0, '女', '化工学院', '4', NULL, '制药', '硕士', '', '三级', '2009-10-03');
INSERT INTO `apply` VALUES (33, '张伟', '2023-06-07 02:57:00', NULL, '郑州大学', 0, '男', '文法学院', '5', NULL, '语文', '硕士', '', '高级', '2012-12-29');
INSERT INTO `apply` VALUES (35, '李国庆', '2023-06-07 03:00:21', NULL, '河南农业大学', 0, '男', '农学院', '7', NULL, '植物', '硕士', '', '三级', '2000-09-19');
INSERT INTO `apply` VALUES (36, '朱文', '2023-06-07 07:14:29', NULL, '河南工学院', 0, '女', '艺术学院', '10', NULL, '美术', '硕士', '', '三级', '2009-12-11');
INSERT INTO `apply` VALUES (37, '刘明', '2023-06-07 09:29:08', NULL, '河南农业大学', 0, '男', '动物科学学院', '8', NULL, '牧业', '博士', '', '高级', '1999-09-16');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `power` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '123456', '123456', '男', 0);
INSERT INTO `user` VALUES (2, '33456', '123456', '女', 0);
INSERT INTO `user` VALUES (3, '456789', '123456', '男', 0);
INSERT INTO `user` VALUES (4, '1111', '1111', '男', 0);
INSERT INTO `user` VALUES (5, '阿松大', '123456', '男', 0);
INSERT INTO `user` VALUES (9, '1234567', '123456', '男', 0);
INSERT INTO `user` VALUES (10, '123', '123', '男', 0);
INSERT INTO `user` VALUES (11, '张三', '201029', '男', 0);
INSERT INTO `user` VALUES (12, '李四', '123456', '男', 0);
INSERT INTO `user` VALUES (17, '管理', '123123', '男', 0);

SET FOREIGN_KEY_CHECKS = 1;
