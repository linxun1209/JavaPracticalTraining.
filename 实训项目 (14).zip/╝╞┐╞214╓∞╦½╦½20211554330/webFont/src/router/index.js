import VueRouter from "vue-router";
// 引入vuex
// import myVuex from '../store/index'
// 引入组件
import userLogin from "../components/userLogin";
import userRegister from "../components/userRegister";
import fillApplication from "../components/fillApplication";
import applicationManagement from "../components/applicationManagement";

// 创建一个路由器
const router = new VueRouter({
  routes: [
    {
      // 访问路径
      path: "/",
      component: userLogin,
      meta: {
        power: 0,
        title: "登录",
      },
    },
    {
      path: "/register",
      component: userRegister,
      meta: {
        power: 0,
        title: "注册",
      },
    },
    {
      path: "/fillApplication",
      component: fillApplication,
      meta: {
        title: "填写申请表",
      },
    },
    {
      path: "/applicationManagement",
      component: applicationManagement,
      meta: {
        title: "管理申请表",
      },
    },
  ],
});
router.beforeEach((to, from, next) => {
  if (to.meta.power == 0) {
    next();
    return;
  }
  // 判断是否登录
  // if (!myVuex.state.token && !sessionStorage.getItem('token')) {
  //     next('/login')
  //     return
  // }
  next();
});
router.afterEach((to) => {
  document.title = to.meta.title;
});

export default router;
