<template>
  <div>
    <div class="topText">学校教师管理系统</div>
    <div class="content">
      <el-row :gutter="10">
        <el-col :span="12">
          <el-form>
            <el-form-item label="姓名" label-width="80px">
              <el-input v-model="name" clearable placeholder="请输入"></el-input>
            </el-form-item>
          </el-form>
        </el-col>
        <el-col :span="12">
          <el-button type="info" @click="res">重置</el-button>

          <el-button type="success" @click="search">查询</el-button>
          <el-button type="danger" @click="quit">退出</el-button>
          <el-button type="primary" @click="add">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content">
      <el-table :data="tableData" :border="true" style="width: 100%">
        <el-table-column prop="no" label="编号"> </el-table-column>
        <el-table-column prop="applicant" label="姓名">
        </el-table-column>
        <el-table-column prop="sex" label="性别"> </el-table-column>
        <el-table-column prop="zhuanye" label="专业"> </el-table-column>
        <el-table-column prop="xueli" label="学历"> </el-table-column>
        <el-table-column prop="reason" label="毕业院校"> </el-table-column>
        <el-table-column prop="phone" label="所在院系"> </el-table-column>
        <el-table-column prop="zhicheng" label="职称"> </el-table-column>
        <el-table-column prop="riqi" label="工作日期"> </el-table-column>
        <el-table-column label="操作" width="150">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="mini" @click="del(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="content bottom">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="nowPage"
        :page-sizes="[5, 10, 15, 20]" :page-size="size" layout="total, sizes, prev, pager, next, jumper" :total="allNums">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "applicationManagement",
  data() {
    return {
      tableData: [],
      name: "",
      size: 5,
      nowPage: 1,
      allNums: 0,
      nowSize: 0,
    };
  },
  methods: {
    del(data) {
      console.log(data);
      axios({
        method: "DELETE",
        url: "/api/admin/deleteApply",
        params: {
          id: parseInt(data.id),
        },
      })
        .then((result) => {
          if (result.data.msg == "OK") {
            this.$message({
              message: "删除成功",
              type: "success",
            });
            if (this.nowSize == 1 && this.nowPage > 1) {
              this.nowPage--;
            }
            this.getInfo();
          } else {
            this.$message({
              message: "删除失败",
              type: "warning",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    search() {
      // 查询
      this.getInfo();
    },
    res() {
      this.name = ''
      this.getInfo()
    },
    quit() {
      // 退出
      this.$store.commit("QUIT");
      this.$router.push("/");
    },
    handleSizeChange(val) {
      this.size = val;
      this.getInfo();
    },
    handleCurrentChange(val) {
      this.nowPage = val;
      this.getInfo();
    },
    add() {
      this.$router.push("/fillApplication");
    },
    handleEdit(data) {
      localStorage.setItem('data', JSON.stringify(data))
      this.$router.push({
        path: '/fillApplication',
        query: {
          id: data.id
        }
      })
    },
    getInfo() {
      axios({
        method: "GET",
        url: "/api/admin/getAllApply",
        params: {
          beginIndex: this.nowPage,
          name: this.name,
          size: this.size,
        },
      })
        .then((result) => {
          console.log(result);
          this.tableData = result.data.data.records;
          this.allNums = result.data.data.total;
          this.nowSize = result.data.data.records.length;
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
  mounted() {
    this.getInfo();
  },
};
</script>

<style scoped>
.topText {
  font-size: 20px;
  font-weight: bold;
}

.content {
  width: 1200px;
  margin: 20px auto;
}
</style>