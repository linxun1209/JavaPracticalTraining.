<template>
  <div>
    <div class="topText">学校教师管理系统</div>
    <h1>注册</h1>
    <div class="content">
      <el-form>
        <el-form-item label="用户名:" label-width="80px">
          <el-input v-model="name" clearable placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="性别:" label-width="80px">
          <el-radio-group v-model="sex">
            <el-radio label="男"></el-radio>
            <el-radio label="女"></el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="密码:" label-width="80px">
          <el-input
            v-model="password"
            type="password"
            clearable
            placeholder="请输入"
          ></el-input>
        </el-form-item>
        <el-form-item label-width="80px">
          <el-button type="success" @click="reg">注册</el-button>
          <el-button type="primary" @click="login">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "userRegister",
  data() {
    return {
      name: "",
      password: "",
      sex: "",
    };
  },
  methods: {
    reg() {
      if (this.name.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入姓名",
          type: "warning",
        });
        return;
      }
      if (this.password.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入密码",
          type: "warning",
        });
        return;
      }
      if (this.sex.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请选择性别",
          type: "warning",
        });
        return;
      }
      axios({
        method: "POST",
        url: "/api/login/register",
        params: {
          password: this.password,
          sex: this.sex,
          username: this.name,
        },
      })
        .then((result) => {
          console.log(result.data);
          if (result.data.msg == "OK") {
            this.$message({
              message: "注册成功",
              type: "success",
            });
            this.$router.push("/");
          } else {
            this.$message({
              message: "该账号已被注册",
              type: "warning",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    login(){
      this.$router.push("/")
    }
  },
};
</script>

<style>
</style>