<template>
  <div>
    <div class="topText">学校教师管理系统</div>
    <h1>登录</h1>
    <div class="content">
      <el-form>
        <el-form-item label="姓名:" label-width="80px">
          <el-input v-model="name" clearable placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="密码:" label-width="80px">
          <el-input
            v-model="password"
            type="password"
            clearable
            placeholder="请输入"
          ></el-input>
        </el-form-item>
        <el-form-item label-width="80px">
          <el-button type="primary" @click="login">登录</el-button>
          <el-button type="success" @click="reg">注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "userLogin",
  data() {
    return {
      name: "",
      password: "",
    };
  },
  methods: {
    login() {
      if (this.name.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入姓名",
          type: "warning",
        });
        return;
      }
      if (this.password.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入密码",
          type: "warning",
        });
        return;
      }
      axios({
        method: "POST",
        url: "/api/login/login",
        params: {
          password: this.password,
          username: this.name,
        },
      })
        .then((result) => {
          if (result.data.msg == "OK") {
            this.$message({
              message: "登录成功",
              type: "success",
            });
            this.$store.commit("LOGIN", "111111");
            this.$router.push("/applicationManagement");
          } else {
            this.$message({
              message: "账号或密码错误",
              type: "warning",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    reg(){
      this.$router.push("/register")
    }
  },
};
</script>

<style>
</style>