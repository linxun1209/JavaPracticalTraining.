<template>
  <div>
    <div class="topText">学校教师管理系统</div>
    <div class="content">
      <el-form label-width="80px">
        <el-form-item label="编号:">
          <el-input v-model="no" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="姓名:">
          <el-input v-model="name" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="性别:">
          <el-radio-group v-model="sex">
            <el-radio label="男"></el-radio>
            <el-radio label="女"></el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="专业:">
          <el-input v-model="zhuanye" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="学历:">
          <el-input v-model="xueli" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="毕业院校:">
          <el-input v-model="reason" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="所在院系:">
          <el-input v-model="phone" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="职称:">
          <el-input v-model="zhicheng" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="工作日期:">
          <el-input v-model="riqi" placeholder="请输入"></el-input>
        </el-form-item>
        <!-- 操作框 -->
        <el-form-item>
          <el-button type="primary" @click="submit">{{ $route.query.id ? "修改" : '添加' }}</el-button>
          <el-button type="warning" @click="reset">重置</el-button>
          <el-button type="info" @click="add">管理</el-button>
          <el-button type="danger" @click="quit">退出</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "fillApplication",
  data() {
    return {
      name: "",
      sex: "",
      no: '',
      zhuanye: '',
      xueli: '',
      yuanxiao: '',
      yuanxi: '',
      zhicheng: '',
      riqi: '',
      reason: '',
      phone: ''
    };
  },
  methods: {
    add() {
      this.$router.push("/applicationManagement");
    },
    submit() {
      // 提交(判断是否空值)
      if (this.name.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入姓名",
          type: "warning",
        });
        return;
      }
      if (this.sex.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请选择性别",
          type: "warning",
        });
        return;
      }
      if (this.no.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入编号",
          type: "warning",
        });
        return;
      }
      if (this.zhuanye.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入专业",
          type: "warning",
        });
        return;
      }
      if (this.xueli.replace(/(^\s*)|(\s*$)/g, "") == "") {
        this.$message({
          message: "请输入学历",
          type: "warning",
        });
        return;
      }

      if (this.$route.query.id) {
        console.log('修改');
        axios({
          method: 'POST',
          url: '/api/admin/update',
          data: {
            id: this.$route.query.id,
            applicant: this.name,
            sex: this.sex,
            no: this.no,
            zhuanye: this.zhuanye,
            xueli: this.xueli,
            schoolname: this.yuanxiao,
            zhicheng: this.zhicheng,
            riqi: this.riqi,
            phone: this.phone,
            reason: this.reason
          }
        })
          .then(res => {
            console.log(res);
            this.$router.push('/applicationManagement')
          })
        return
      }
      axios({
        method: "POST",
        url: "/api/admin/apply",
        params: {
          applicant: this.name,
          sex: this.sex,
          no: this.no,
          zhuanye: this.zhuanye,
          xueli: this.xueli,
          schoolname: this.yuanxiao,
          zhicheng: this.zhicheng,
          riqi: this.riqi,
          phone: this.phone,
          reason: this.reason
        },
      })
        .then((result) => {
          if (result.data.msg == "OK") {
            this.$message({
              message: "填写成功",
              type: "success",
            });
            this.reset();
          } else {
            this.$message({
              message: "账号或密码错误",
              type: "warning",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    reset() {
      // 重置
      this.name = ""
      this.sex = ""
      this.no = ''
      this.zhuanye = ''
      this.xueli = ''
      this.yuanxiao = ''
      this.yuanxi = ''
      this.zhicheng = ''
      this.riqi = ''
      this.reason = ''
      this.phone = ''
    },
    quit() {
      // 退出
      this.$store.commit("QUIT");
      this.$router.push("/");
    },
    handleChange(val) {
      this.num = val;
    },
  },
  mounted() {
    if (this.$route.query.id) {
      console.log(localStorage.getItem("data"));
      let dataInfo = JSON.parse(localStorage.getItem('data'))
      this.name = dataInfo.applicant
      this.sex = dataInfo.sex
      this.no = dataInfo.no
      this.zhuanye = dataInfo.zhuanye
      this.xueli = dataInfo.xueli
      this.yuanxi = dataInfo.yuanxi
      this.zhicheng = dataInfo.zhicheng
      this.riqi = dataInfo.riqi
      this.reason = dataInfo.reason
      this.phone = dataInfo.phone
    }
  }
};
</script>

<style>
.topText {
  font-size: 20px;
  font-weight: bold;
}

.content {
  width: 800px;
  margin: 20px auto;
}

.el-radio-group {
  position: relative;
  left: -300px;
}

.el-input-number {
  position: relative;
  left: -270px;
}
</style>