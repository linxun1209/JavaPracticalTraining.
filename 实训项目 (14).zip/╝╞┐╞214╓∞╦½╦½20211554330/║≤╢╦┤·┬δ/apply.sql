/*
 Navicat Premium Data Transfer

 Source Server         : 本地
 Source Server Type    : MySQL
 Source Server Version : 50714
 Source Host           : localhost:3306
 Source Schema         : lx

 Target Server Type    : MySQL
 Target Server Version : 50714
 File Encoding         : 65001

 Date: 06/06/2023 15:13:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for apply
-- ----------------------------
DROP TABLE IF EXISTS `apply`;
CREATE TABLE `apply`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicant` varchar(110) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `create_time` datetime(0) DEFAULT NULL,
  `apply_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `sex` varchar(110) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(110) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `zhuanye` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `xueli` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `schoolname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `zhicheng` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `riqi` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of apply
-- ----------------------------
INSERT INTO `apply` VALUES (1, '申请人', '2022-12-24 11:11:41', '农业', '我想当', 0, '男', '110', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (2, '所属', '2022-12-24 03:55:53', '农业', '啊实打实的', 0, '男', '123456', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (3, '啊实打实', '2022-12-24 04:01:13', '阿萨', '撒旦的方法灌灌', 0, '男', '645456465', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (4, '啊实打实', '2022-12-24 04:01:28', '阿萨', '撒旦的方法灌灌', 0, '男', '645456465', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (5, '11', '2022-12-24 04:04:28', '1', '11', 1, '男', '18836193515', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (7, '所属', '2022-12-24 04:18:45', '农业', '啊实打实的', 0, '男', '123456', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (8, '所属', '2022-12-24 04:18:46', '农业', '啊实打实的', 0, '男', '123456', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (9, '所属', '2022-12-24 04:18:48', '农业', '啊实打实的', 0, '男', '123456', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (10, '所属', '2022-12-24 04:18:48', '农业', '啊实打实的', 0, '男', '123456', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `apply` VALUES (11, NULL, '2023-06-06 02:16:15', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
