package com.example.technology.filter;

import com.example.technology.util.UserHolder;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author DELL
 **/
@Slf4j
@WebFilter(urlPatterns = "/admin/*",filterName = "MyFilter")
public class MyFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        //向上转型
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        log.info("进入过滤......");

        log.info("成功了");
        UserHolder.saveUser(UserHolder.getUser());
        filterChain.doFilter(request,response);
        //放行
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}
