package com.example.technology.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.technology.entity.Apply;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface ApplyMapper extends BaseMapper<Apply> {
}
