package com.example.technology.control;

import com.example.technology.entity.Apply;
import com.example.technology.service.AdminService;
import com.example.technology.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;
    @PostMapping("/apply")
    public JsonResult apply(@ModelAttribute Apply apply){
        return adminService.apply(apply);
    }
    @GetMapping("/getAllApply")
    public JsonResult getAllApply(@RequestParam(required = false) String name,@RequestParam Integer beginIndex,@RequestParam Integer size){
        return adminService.getAllApply(name,beginIndex,size);
    }
    @DeleteMapping("/deleteApply")
    public JsonResult deleteApply(@RequestParam Integer id){
        return adminService.deleteApply(id);
    }
    @PostMapping("/update")
    public JsonResult update(@RequestBody Apply apply){
       return adminService.update(apply);
    }

}
