package com.example.technology.service.imp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.technology.entity.Apply;
import com.example.technology.entity.User;
import com.example.technology.mapper.ApplyMapper;
import com.example.technology.mapper.UserMapper;
import com.example.technology.service.AdminService;
import com.example.technology.util.JsonResult;
import com.example.technology.util.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * @author DELL
 **/
@Service
public class AdminServiceImp implements AdminService {
    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ApplyMapper applyMapper;
    @Override
    public JsonResult login(String username, String password) {
        QueryWrapper<User> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("name",username).eq("password",password);
        User user = userMapper.selectOne(queryWrapper);
        if (!StringUtils.isEmpty(user)){
            UserHolder.saveUser(user);
            return JsonResult.ok();
        }
        return JsonResult.error();
    }

    @Override
    public JsonResult register(String username, String password, String sex) {
        int i = userMapper.insert(new User(null, username, password, sex, null));
        return i>0?JsonResult.ok():JsonResult.error();
    }

    @Override
    public JsonResult apply(Apply apply) {
        int i = applyMapper.insert(apply);
        return i>0?JsonResult.ok():JsonResult.error();
    }

    @Override
    public JsonResult getAllApply(String name, Integer beginIndex, Integer size) {
        QueryWrapper<Apply> queryWrapper=new QueryWrapper<>();
        queryWrapper.like(!StringUtils.isEmpty(name),"applicant",name);
        Page<Apply> applyPage = applyMapper.selectPage(new Page<>(beginIndex, size), queryWrapper);
        return JsonResult.ok(applyPage);
    }

    @Override
    public JsonResult deleteApply(Integer id) {
        return applyMapper.deleteById(id)>0?JsonResult.ok():JsonResult.error();
    }

    @Override
    public JsonResult update(Apply apply) {
        return applyMapper.updateById(apply) > 0?JsonResult.ok():JsonResult.error();
    }
}
