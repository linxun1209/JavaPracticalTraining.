package com.example.technology.util;


import com.example.technology.entity.User;

/**
 * @author DELL
 */
public class UserHolder {
    private static final ThreadLocal<User> tl=new InheritableThreadLocal<>();

    public static void saveUser(User user){
        tl.set(user);
    }

    public static User getUser(){
        return tl.get();
    }

    public static void removeUser(){
        tl.remove();
    }
    public static Integer getUserId(){
        return tl.get().getId();
    }
}
