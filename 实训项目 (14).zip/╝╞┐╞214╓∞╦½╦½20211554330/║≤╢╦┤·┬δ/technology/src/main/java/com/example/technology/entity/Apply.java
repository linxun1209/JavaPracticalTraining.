package com.example.technology.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("apply")
@ApiModel
public class Apply implements Serializable {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String applicant;
    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;
    @TableField("apply_type")
    private String applyType;
    private String reason;
    private Integer status;
    private String phone;
//    性别
    private String sex;
//    编号
    private String no;
//    姓名
    private String name;
//    专业
    private String zhuanye;
//    学历
    private String xueli;
//    毕业院校
    private String schoolname;
//    职称
    private String zhicheng;
//    参加工作日期
    private String riqi;

}
