package com.example.technology.control;

import com.example.technology.service.AdminService;
import com.example.technology.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author DELL
 **/
//@RequestMapping注解的作用就是将请求和处理请求的控制器方法关联起来，建立映射关系。
@RestController
@RequestMapping("/login")
public class LoginAndRegisterController {
    @Autowired
    private AdminService adminService;
    @PostMapping("/login")
    public JsonResult login(String username, String password){
        return adminService.login(username, password);
    }
    @PostMapping("/register")
    public JsonResult register(String username,String password,String sex){
        return adminService.register(username, password,sex);
    }
}
