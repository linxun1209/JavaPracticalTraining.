package com.example.technology.service;

import com.example.technology.entity.Apply;
import com.example.technology.util.JsonResult;
import org.springframework.stereotype.Service;

@Service
public interface AdminService {
    JsonResult login(String username, String password);

    JsonResult register(String username, String password, String sex);

    JsonResult apply(Apply apply);

    JsonResult getAllApply(String name, Integer beginIndex, Integer size);

    JsonResult deleteApply(Integer id);
    JsonResult update(Apply apply);

}
