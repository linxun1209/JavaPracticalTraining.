/*
 Navicat Premium Data Transfer

 Source Server         : tengxun
 Source Server Type    : MySQL
 Source Server Version : 80031
 Source Host           : 152.136.99.236:3306
 Source Schema         : technology

 Target Server Type    : MySQL
 Target Server Version : 80031
 File Encoding         : 65001

 Date: 24/12/2022 12:51:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for apply
-- ----------------------------
DROP TABLE IF EXISTS `apply`;
CREATE TABLE `apply`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicant` varchar(110) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `apply_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT 0,
  `sex` varchar(110) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `phone` varchar(110) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of apply
-- ----------------------------
INSERT INTO `apply` VALUES (1, '申请人', '2022-12-24 11:11:41', '农业', '我想当', 0, '男', '110');
INSERT INTO `apply` VALUES (2, '所属', '2022-12-24 03:55:53', '农业', '啊实打实的', 0, '男', '123456');
INSERT INTO `apply` VALUES (3, '啊实打实', '2022-12-24 04:01:13', '阿萨', '撒旦的方法灌灌', 0, '男', '645456465');
INSERT INTO `apply` VALUES (4, '啊实打实', '2022-12-24 04:01:28', '阿萨', '撒旦的方法灌灌', 0, '男', '645456465');
INSERT INTO `apply` VALUES (5, '11', '2022-12-24 04:04:28', '1', '11', 1, '男', '18836193515');
INSERT INTO `apply` VALUES (7, '所属', '2022-12-24 04:18:45', '农业', '啊实打实的', 0, '男', '123456');
INSERT INTO `apply` VALUES (8, '所属', '2022-12-24 04:18:46', '农业', '啊实打实的', 0, '男', '123456');
INSERT INTO `apply` VALUES (9, '所属', '2022-12-24 04:18:48', '农业', '啊实打实的', 0, '男', '123456');
INSERT INTO `apply` VALUES (10, '所属', '2022-12-24 04:18:48', '农业', '啊实打实的', 0, '男', '123456');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `sex` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `power` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '123456', '123456', '男', 0);
INSERT INTO `user` VALUES (2, '33456', '123456', '女', 0);
INSERT INTO `user` VALUES (3, '456789', '123456', '男', 0);
INSERT INTO `user` VALUES (4, '1111', '1111', '男', 0);
INSERT INTO `user` VALUES (5, '阿松大', '123456', '男', 0);
INSERT INTO `user` VALUES (9, '1234567', '123456', '男', 0);
INSERT INTO `user` VALUES (10, '123', '123', '男', 0);

SET FOREIGN_KEY_CHECKS = 1;
