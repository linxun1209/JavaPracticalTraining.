package com.demo.pojo;

import lombok.*;
import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class Donor {
    private Integer id;
    private String number;
    private String name;
    private String gender;
    private String idNumber;
    private String amount;
    private Date date;
    private Integer category;

}
