package com.demo.web;

import com.demo.dao.Dao;
import com.demo.pojo.Donor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/add")
public class Add extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        //接收参数
        String number = req.getParameter("number");
        String name = req.getParameter("name");
        String gender = req.getParameter("gender");
        String idNumber = req.getParameter("idNumber");
        String amount = req.getParameter("amount");
        String date = req.getParameter("date");
        String category = req.getParameter("category");
        //封装对象
        Donor donor = new Donor();
        donor.setNumber(number);
        donor.setName(name);
        donor.setGender(gender);
        donor.setIdNumber(idNumber);
        donor.setAmount(amount);
        donor.setDate(Date.valueOf(date));
        donor.setCategory(Integer.parseInt(category));
        //调用Dao方法完成添加
        Dao dao = Dao.getInstance();
        dao.add(donor);
        req.getRequestDispatcher("/index.jsp").forward(req,resp);
    }
}
