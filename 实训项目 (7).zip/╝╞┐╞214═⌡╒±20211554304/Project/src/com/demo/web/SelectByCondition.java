package com.demo.web;

import com.demo.dao.Dao;
import com.demo.pojo.Donor;
import com.mysql.cj.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 多框查询
 */
@WebServlet("/selectByCondition")
public class SelectByCondition extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        //接收前端传过来的参数
        String name = req.getParameter("name");
        String sex = req.getParameter("sex");
        String shen = req.getParameter("shen");
        String amount = req.getParameter("amount");
        String date = req.getParameter("date");
        //声明str字符串类型为空，声明num
        String str = "";
        int num=0;
        //判断每个框中的数据是否为空
        //判断name文本框传入的参数是否为空
        if (!StringUtils.isNullOrEmpty(name)){
            //若不为空则将str与后面的模糊查询语句拼接num++
            str+="name like '%"+name+"%' ";
            num++;
        }
        //判断sex文本框传入的参数是否为空
        if (!StringUtils.isNullOrEmpty(sex)){
            //若sex不为空，且num不为0，str与and拼接
            if (num!=0){
                str+="AND ";
            }
            //str与后面的模糊查询语句拼接num++
            str+="gender='"+sex+"'";
            num++;
        }
        if (!StringUtils.isNullOrEmpty(shen)){
            if (num!=0){
                str+="AND ";
            }
            str+="idNumber='"+shen+"'";
            num++;
        }
        if (!StringUtils.isNullOrEmpty(amount)){
            if (num!=0){
                str+="AND ";
            }
            str+="amount='"+amount+"'";
            num++;
        }
        if(num!=0) {
            str += ";";
            //拼接的str语句传入selectByCondition方法与Dao中语句拼接形成完整的sql语句
            Dao dao = Dao.getInstance();
            List<Donor> donors = dao.selectByCondition(str);
            //存入request域中呈现在前端页面
            req.setAttribute("donors", donors);
            //转发到home.jsp
            req.getRequestDispatcher("/home.jsp").forward(req, resp);
        }else{
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
        }
    }
}
