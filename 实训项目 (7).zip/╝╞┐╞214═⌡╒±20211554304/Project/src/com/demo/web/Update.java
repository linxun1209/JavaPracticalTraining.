package com.demo.web;

import com.demo.dao.Dao;
import com.demo.pojo.Donor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/update")
public class Update extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //解决乱码
        req.setCharacterEncoding("utf-8");
        //接收参数
        String number = req.getParameter("number");
        System.out.println(number);
        String name = req.getParameter("name");
        System.out.println(name);
        String gender = req.getParameter("gender");
        System.out.println(gender);
        String idNumber = req.getParameter("idNumber");
        System.out.println(idNumber);
        String amount = req.getParameter("amount");
        System.out.println(amount);
        String date = req.getParameter("date");
        System.out.println(date);
        String category = req.getParameter("category");
        System.out.println(category);
        //封装对象
        Donor donor = new Donor();
        donor.setNumber(number);
        donor.setName(name);
        donor.setGender(gender);
        donor.setIdNumber(idNumber);
        donor.setAmount(amount);
        donor.setDate(Date.valueOf(date));
        donor.setCategory(Integer.parseInt(category));
        //调用Dao方法完成修改
        Dao dao = Dao.getInstance();
        Boolean update = dao.update(donor);
        //System.out.println(update);
        req.getRequestDispatcher("/index.jsp").forward(req,resp);
    }
}
