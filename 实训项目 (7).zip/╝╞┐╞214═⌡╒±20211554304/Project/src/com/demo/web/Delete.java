package com.demo.web;

import com.demo.dao.Dao;
import com.demo.pojo.Donor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/delete")
public class Delete extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //接收number
        String number = req.getParameter("number");
        System.out.println(number);
        Donor donor = new Donor();
        donor.setNumber(number);
        //删除操作
        Dao dao = Dao.getInstance();
        dao.delete(donor);
        //返回主页面
        req.getRequestDispatcher("/index.jsp").forward(req,resp);
    }
}
