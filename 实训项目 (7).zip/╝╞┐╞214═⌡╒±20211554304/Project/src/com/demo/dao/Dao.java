package com.demo.dao;

import com.demo.pojo.Donor;
import com.demo.utils.JDBCUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Dao {
    public static Dao dao =null;
    private Dao(){}
    public static Dao getInstance(){
        if (dao==null){
            synchronized (Dao.class){
                if (dao==null){
                    dao=new Dao();
                }
            }
        }
        return dao;
    }

    /**
     * 查询所有
     * @return
     */
    public List<Donor>selectAll(){
        List<Donor> donorList = new ArrayList<>();
        PreparedStatement prepared = null;
        Connection conn=null;
        ResultSet resultSet=null;
        try{
            conn = JDBCUtils.getConnection();

            //查询操作
            String sql = "select * from tb_donor";
            prepared= conn.prepareStatement(sql);
            resultSet = prepared.executeQuery();
            while (resultSet.next()){
                Donor d = new Donor();
                d.setId(resultSet.getInt("id"));
                d.setNumber(resultSet.getString("number"));
                d.setName(resultSet.getString("name"));
                d.setGender(resultSet.getString("gender"));
                d.setIdNumber(resultSet.getString("idNumber"));
                d.setAmount(resultSet.getString("amount"));
                d.setDate(resultSet.getDate("date"));
                d.setCategory(resultSet.getInt("category"));
                donorList.add(d);
            }
        }catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDBCUtils.close(resultSet,prepared,conn);
        }
        return donorList;
    }

    /**
     * 添加数据
     * @param donor
     * @return
     */
    public Boolean add(Donor donor){
        //JDBC六个步骤
        Connection conn=null;
        PreparedStatement preparedStatement =null;
        ResultSet resultSet=null;
        List<Donor>donorList=new ArrayList<>();
        Integer i =null;
        try{

            conn = JDBCUtils.getConnection();
            //
            String sql ="insert into tb_donor(number,name,gender,idNumber,amount,date,category) values(?,?,?,?,?,?,?)";
            preparedStatement = conn.prepareStatement(sql);

            //给值
            preparedStatement.setString(1,donor.getNumber());
            preparedStatement.setString(2,donor.getName());
            preparedStatement.setString(3,donor.getGender());
            preparedStatement.setString(4,donor.getIdNumber());
            preparedStatement.setString(5,donor.getAmount());
            preparedStatement.setDate(6,donor.getDate());
            preparedStatement.setInt(7,donor.getCategory());

            i = preparedStatement.executeUpdate();

        }catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDBCUtils.close(resultSet,preparedStatement,conn);
        }
        return i>0;
    }

    /**
     * 删除数据
     * @param donor
     * @return
     */
    public Boolean delete(Donor donor){

        Connection conn = null;
        PreparedStatement prepared = null;
        ResultSet resultSet = null;
        Integer row=null;

        try{
            conn = JDBCUtils.getConnection();
            String sql="delete from tb_donor where number =?";
            prepared = conn.prepareStatement(sql);
            prepared.setString(1,donor.getNumber());
            row =prepared.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            JDBCUtils.close(resultSet,prepared,conn);
        }
        return row>0;
    }
    /**
     * 修改数据
     */
    public Boolean update(Donor donor){
        Connection conn=null;
        PreparedStatement prepared = null;
        ResultSet resultSet = null;
        Integer row=null;
        try{
            conn=JDBCUtils.getConnection();
            String sql="update tb_donor set name=?,gender=?,idNumber=?,amount=?,date=?,category=? where number =?";
            prepared = conn.prepareStatement(sql);
            prepared.setString(1,donor.getName());
            prepared.setString(2,donor.getGender());
            prepared.setString(3,donor.getIdNumber());
            prepared.setString(4,donor.getAmount());
            prepared.setDate(5,donor.getDate());
            prepared.setInt(6,donor.getCategory());
            prepared.setString(7,donor.getNumber());
            row =prepared.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            JDBCUtils.close(resultSet,prepared,conn);
        }
        return row>0;
    }

    /**
     * 多条件查询
     */
    public List<Donor>selectByCondition(String sql){
        List<Donor> donorList = new ArrayList<>();
        PreparedStatement prepared = null;
        Connection conn=null;
        ResultSet resultSet=null;
        try{
            conn = JDBCUtils.getConnection();
            //查询操作
            String sql1 = "select * from tb_donor where ";
            sql1 = sql1.concat(sql);
            prepared= conn.prepareStatement(sql1);
            resultSet = prepared.executeQuery();
            while (resultSet.next()){
                Donor d = new Donor();
                d.setId(resultSet.getInt("id"));
                d.setNumber(resultSet.getString("number"));
                d.setName(resultSet.getString("name"));
                d.setGender(resultSet.getString("gender"));
                d.setIdNumber(resultSet.getString("idNumber"));
                d.setAmount(resultSet.getString("amount"));
                d.setDate(resultSet.getDate("date"));
                d.setCategory(resultSet.getInt("category"));
                donorList.add(d);
            }
        }
        catch (SQLException e){
            throw new RuntimeException(e);
        } finally {
            JDBCUtils.close(resultSet,prepared,conn);
        }
        return donorList;
    }
}
