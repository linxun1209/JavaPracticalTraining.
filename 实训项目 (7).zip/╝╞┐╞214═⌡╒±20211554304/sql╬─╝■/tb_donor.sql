/*
 Navicat Premium Data Transfer

 Source Server         : 本机
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : db1

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 09/06/2023 11:00:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_donor
-- ----------------------------
DROP TABLE IF EXISTS `tb_donor`;
CREATE TABLE `tb_donor`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `number` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `gender` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `idNumber` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `amount` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `category` int(0) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_donor
-- ----------------------------
INSERT INTO `tb_donor` VALUES (33, '53440606MJL679479J', '李华', '男', '410111200001012580', '1000', '2023-06-08', 0);
INSERT INTO `tb_donor` VALUES (34, '514307036895134890', '蔡徐坤', '男', '330300199808022580', '10w', '2023-06-08', 0);
INSERT INTO `tb_donor` VALUES (35, '53445300MJM725182R', '泥干妈', '男', '330300199808021470', '25w', '2023-06-08', 0);
INSERT INTO `tb_donor` VALUES (36, '53441300MJM039019K', '张三', '男', '410132200001012580', '1000', '2023-06-08', 0);
INSERT INTO `tb_donor` VALUES (37, '53320100MJ55871537', '李四', '女', '410111199909092580', '1w', '2023-06-08', 0);
INSERT INTO `tb_donor` VALUES (38, '533200005091582225', '王五', '女', '411011198005052580', '2000', '2023-06-08', 1);
INSERT INTO `tb_donor` VALUES (39, '53320100336416392E', '赵六', '男', '233233199002282580', '3000', '2023-06-08', 0);
INSERT INTO `tb_donor` VALUES (41, '53330100MJ8777980J', '王小美', '女', '410123200012302580', '2w', '2023-06-04', 0);

SET FOREIGN_KEY_CHECKS = 1;
