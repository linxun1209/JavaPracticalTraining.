/*
 Navicat Premium Data Transfer

 Source Server         : 002
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : mysql

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 09/06/2023 11:24:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for gra_users
-- ----------------------------
DROP TABLE IF EXISTS `gra_users`;
CREATE TABLE `gra_users`  (
  `id` int(11) NOT NULL,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `password` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gra_users
-- ----------------------------
INSERT INTO `gra_users` VALUES (1, 'lqs', '666666');
INSERT INTO `gra_users` VALUES (2, 'gly', '000000');

SET FOREIGN_KEY_CHECKS = 1;
