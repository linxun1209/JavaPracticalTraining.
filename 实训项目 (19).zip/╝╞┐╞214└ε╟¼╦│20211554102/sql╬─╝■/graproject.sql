/*
 Navicat Premium Data Transfer

 Source Server         : 002
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : mysql

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 09/06/2023 11:24:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for graproject
-- ----------------------------
DROP TABLE IF EXISTS `graproject`;
CREATE TABLE `graproject`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `className` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `stuName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `proName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `staTime` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `endTime` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `proTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `score` double NULL DEFAULT NULL,
  `teacher` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of graproject
-- ----------------------------
INSERT INTO `graproject` VALUES (357, '20211554102', '计科214', '刘鹏飞', '如何学好java', '论文', '三月一号', '五月十五号', '五月二十号', 99, '刘老师');
INSERT INTO `graproject` VALUES (369, '20211554105', '计科213', '褚满', '人生的自我修养', '论文', '三月二号', '五月八号', '六月十号', 100, '李老师');
INSERT INTO `graproject` VALUES (635, '111', '计科213', '王五', '论王五为什么这么多', '汇报表演', '三月四号', '六月一号', '六月三号上午', 98, '王老师');

SET FOREIGN_KEY_CHECKS = 1;
