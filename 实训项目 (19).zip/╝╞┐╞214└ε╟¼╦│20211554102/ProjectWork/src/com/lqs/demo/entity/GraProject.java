package com.lqs.demo.entity;

public class GraProject {
    private  Integer id;//编号
    private String stuNumber;//学号
    private String className;//班级
    private String stuName;//姓名
    private  String proName;//题目
    private  String type;//类型
    private  String staTime;//开始时间
    private  String endTime;//结束时间
    private  String proTime;//答辩时间
    private  double score;//得分
    private  String teacher;//指导老师

    public GraProject(Integer id, String stuNumber, String className, String stuName, String proName, String type, String staTime, String endTime, String proTime, double score, String teacher) {
        this.id = id;
        this.stuNumber = stuNumber;
        this.className = className;
        this.stuName = stuName;
        this.proName = proName;
        this.type = type;
        this.staTime = staTime;
        this.endTime = endTime;
        this.proTime = proTime;
        this.score = score;
        this.teacher = teacher;
    }

    public GraProject() {

    }

    @Override
    public String toString() {
        return "GraProject{" +
                "id=" + id +
                ", stuNumber='" + stuNumber + '\'' +
                ", className='" + className + '\'' +
                ", stuName='" + stuName + '\'' +
                ", proName='" + proName + '\'' +
                ", type='" + type + '\'' +
                ", staTime='" + staTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", proTime='" + proTime + '\'' +
                ", score=" + score +
                ", teacher='" + teacher + '\'' +
                '}';
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStuNumber() {
        return stuNumber;
    }

    public void setStuNumber(String stuNumber) {
        this.stuNumber = stuNumber;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getProName() {
        return proName;
    }

    public void setProName(String proName) {
        this.proName = proName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStaTime() {
        return staTime;
    }

    public void setStaTime(String staTime) {
        this.staTime = staTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getProTime() {
        return proTime;
    }

    public void setProTime(String proTime) {
        this.proTime = proTime;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }
}
