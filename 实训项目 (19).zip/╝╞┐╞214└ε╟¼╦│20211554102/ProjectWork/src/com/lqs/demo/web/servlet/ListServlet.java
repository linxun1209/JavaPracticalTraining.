package com.lqs.demo.web.servlet;

import com.lqs.demo.dao.GraProjectDao;
import com.lqs.demo.entity.GraProject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/listServlet")
public class ListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        GraProjectDao graProjectDao=GraProjectDao.getInstance();
        List<GraProject> graProjects=graProjectDao.selectAllGraProject();
        System.out.println(graProjects);
        req.setAttribute("graProjectList",graProjects);
        RequestDispatcher requestDispatcher=req.getRequestDispatcher("/list.jsp");
        requestDispatcher.forward(req,resp);
    }
}
