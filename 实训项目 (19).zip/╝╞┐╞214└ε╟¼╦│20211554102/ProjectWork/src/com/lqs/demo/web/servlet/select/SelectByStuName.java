package com.lqs.demo.web.servlet.select;

import com.lqs.demo.dao.GraProjectDao;
import com.lqs.demo.entity.GraProject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/selectByStuName")
public class SelectByStuName extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String stuName=req.getParameter("stuName");
        GraProjectDao graProjectDao=GraProjectDao.getInstance();
        List<GraProject> graProjects=graProjectDao.SelectByStuName(stuName);
        req.setAttribute("graProjectList",graProjects);
        RequestDispatcher requestDispatcher=req.getRequestDispatcher("/list.jsp");
        requestDispatcher.forward(req,resp);
    }
}