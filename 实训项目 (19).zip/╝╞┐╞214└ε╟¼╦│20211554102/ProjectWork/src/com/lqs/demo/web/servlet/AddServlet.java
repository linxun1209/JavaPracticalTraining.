package com.lqs.demo.web.servlet;

import com.lqs.demo.dao.GraProjectDao;
import com.lqs.demo.entity.GraProject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/addServlet")
public class AddServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       req.setCharacterEncoding("UTF8");
//        //接受参数
        Integer id = Integer.parseInt(req.getParameter("id"));
        String stuNumber = req.getParameter("stuNumber");
        String className = req.getParameter("className");
        String stuName = req.getParameter("stuName");
        String proName = req.getParameter("proName");
        String type = req.getParameter("type");
        String staTime = req.getParameter("staTime");
        String endTime = req.getParameter("endTime");
        String proTime = req.getParameter("proTime");
        String score = req.getParameter("score");
        String teacher = req.getParameter("teacher");
        //封装对象
        GraProject graProject=new GraProject();
        graProject.setId(id);
        graProject.setStuNumber(stuNumber);
        graProject.setClassName(className);
        graProject.setStuName(stuName);
        graProject.setProName(proName);
        graProject.setType(type);
        graProject.setStaTime(staTime);
        graProject.setEndTime(endTime);
        graProject.setProTime(proTime);
        graProject.setScore(Double.parseDouble(score));
        graProject.setTeacher(teacher);
        //调用GraProjectDao中的addGraProject方法

        GraProjectDao graProjectDao=GraProjectDao.getInstance();
        try {
            if (graProjectDao.pan(id)){
                resp.sendRedirect("add.jsp?error=no");
            }else{

                Integer row1=graProjectDao.addGraProject(graProject);
                List<GraProject> graProjects=graProjectDao.selectAllGraProject();
                req.setAttribute("graProjectList",graProjects);
                RequestDispatcher requestDispatcher=req.getRequestDispatcher("/list.jsp");
                requestDispatcher.forward(req,resp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


//        Integer row1=graProjectDao.addGraProject(graProject);
//       List<GraProject> graProjects=graProjectDao.selectAllGraProject();
//       req.setAttribute("graProjectList",graProjects);
//       RequestDispatcher requestDispatcher=req.getRequestDispatcher("/list.jsp");
//       requestDispatcher.forward(req,resp);

    }
}
