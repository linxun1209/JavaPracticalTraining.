package com.lqs.demo.web.servlet;

import com.lqs.demo.dao.GraProjectDao;
import com.lqs.demo.entity.GraProject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/updateServlet")
public class UpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id1= Integer.valueOf(req.getParameter("id"));

        GraProjectDao graProjectDao=GraProjectDao.getInstance();
        GraProject graProject= graProjectDao.getGraProjectByTd(String.valueOf(id1));


        req.setAttribute("graProject",graProject);
        req.getRequestDispatcher("update.jsp").forward(req, resp);

    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取表单提交的学生信息
        req.setCharacterEncoding("UTF8");
        int id= Integer.parseInt(req.getParameter("id"));
        String stuNumber = req.getParameter("stuNumber");
        String className = req.getParameter("className");
        String stuName = req.getParameter("stuName");
        String proName = req.getParameter("proName");
        String type = req.getParameter("type");
        String staTime = req.getParameter("staTime");
        String endTime = req.getParameter("endTime");
        String proTime = req.getParameter("proTime");
        Double score = Double.valueOf(req.getParameter("score"));
        String teacher = req.getParameter("teacher");

        GraProject graProject=new GraProject();
        graProject.setId(id);
        graProject.setStuNumber(stuNumber);
        graProject.setClassName(className);
        graProject.setStuName(stuName);
        graProject.setProName(proName);
        graProject.setType(type);
        graProject.setStaTime(staTime);
        graProject.setEndTime(endTime);
        graProject.setProTime(proTime);
        graProject.setScore(Double.parseDouble(String.valueOf(score)));
        graProject.setTeacher(teacher);

        GraProjectDao graProjectDao=GraProjectDao.getInstance();
        Integer row1=graProjectDao.UpdateGraProject(graProject);
        List<GraProject> graProjects=graProjectDao.selectAllGraProject();
        req.setAttribute("graProjectList",graProjects);
        RequestDispatcher requestDispatcher=req.getRequestDispatcher("/list.jsp");
        requestDispatcher.forward(req,resp);

    }
}
//        String id1=req.getParameter("id");
// //接受参数
//        Integer id = Integer.parseInt(req.getParameter("id"));
//        String stuNumber = req.getParameter("stuNumber");
//        String className = req.getParameter("className");
//        String stuName = req.getParameter("stuName");
//        String proName = req.getParameter("proName");
//        String type = req.getParameter("type");
//        String staTime = req.getParameter("staTime");
//        String endTime = req.getParameter("endTime");
//        String proTime = req.getParameter("proTime");
//        String score = req.getParameter("score");
//        String teacher = req.getParameter("teacher");
//        //封装对象
//        GraProject graProject=new GraProject();
//        graProject.setId(id);
//        graProject.setStuNumber(stuNumber);
//        graProject.setClassName(className);
//        graProject.setStuName(stuName);
//        graProject.setProName(proName);
//        graProject.setType(type);
//        graProject.setStaTime(staTime);
//        graProject.setEndTime(endTime);
//        graProject.setProTime(proTime);
//        graProject.setScore(Double.parseDouble(score));
//        graProject.setTeacher(teacher);
//        //调用GraProjectDao中的addGraProject方法
//
//        GraProjectDao graProjectDao=GraProjectDao.getInstance();
//        graProjectDao.UpdateGraProject(id1);
//        List<GraProject> graProjectList=graProjectDao.selectAllGraProject();
//
//        req.setAttribute("graProjectList",graProjectList);
//        req.getRequestDispatcher("list.jsp").forward(req, resp);