package com.lqs.demo.web.servlet.select;

import com.lqs.demo.dao.GraProjectDao;
import com.lqs.demo.entity.GraProject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/selectByIdServlet")
public class SelectByIdServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        Integer id2= Integer.valueOf(req.getParameter("id"));
        GraProjectDao graProjectDao=GraProjectDao.getInstance();
        try {
            if (graProjectDao.pan(id2)){
                List<GraProject> graProjects=graProjectDao.SelectById(String.valueOf(id2));
                req.setAttribute("graProjectList",graProjects);
                RequestDispatcher requestDispatcher=req.getRequestDispatcher("/list.jsp");
                requestDispatcher.forward(req,resp);
            }else {
                resp.sendRedirect("list.jsp?error=no");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
