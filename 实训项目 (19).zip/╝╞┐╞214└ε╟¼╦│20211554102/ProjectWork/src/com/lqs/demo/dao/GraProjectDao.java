package com.lqs.demo.dao;

import com.lqs.demo.entity.GraProject;
import com.lqs.demo.utils.JDbcUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.lqs.demo.utils.JDbcUtils.getConnection;

public class GraProjectDao {
    public static GraProjectDao graProjectDao=null;

    public GraProjectDao(){}
    public static GraProjectDao getInstance(){
        if (graProjectDao==null){
            synchronized (GraProjectDao.class){
                if (graProjectDao==null){
                    graProjectDao=new GraProjectDao();
                }
            }
        }
        return graProjectDao;
    }

    //展示所有毕业设计
    public List<GraProject> selectAllGraProject(){
        Connection conn=null;
        PreparedStatement prepared=null;
        List<GraProject> graProjectList=new ArrayList<>();
        ResultSet resultSet=null;
        try {
            conn = getConnection();
            String sql ="select * from graproject";
            prepared=conn.prepareStatement(sql);
            resultSet =prepared.executeQuery();
            while (resultSet.next()){
                GraProject g=new GraProject();
                g.setId(resultSet.getInt("id"));
                g.setStuNumber(resultSet.getString("stuNumber"));
                g.setClassName(resultSet.getString("className"));
                g.setStuName(resultSet.getString("stuName"));
                g.setProName(resultSet.getString("proName"));
                g.setType(resultSet.getString("type"));
                g.setStaTime(resultSet.getString("staTime"));
                g.setEndTime(resultSet.getString("endTime"));
                g.setProTime(resultSet.getString("proTime"));
                g.setScore(resultSet.getDouble("score"));
                g.setTeacher(resultSet.getString("teacher"));
                graProjectList.add(g);
            }

        } catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDbcUtils.close(resultSet,prepared,conn);
        }
        return graProjectList;
    }
    //添加功能
    public Integer addGraProject(GraProject graProject){
        Connection conn=null;
        PreparedStatement prepared=null;
        ResultSet resultSet=null;
        try {
            conn = getConnection();
            //添加操作
            String sql ="insert into graproject(id,stuNumber,className,stuName,proName,type,staTime,endTime,proTime,score,teacher) " +
                    "values(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement preparedStatement=conn.prepareStatement(sql);
            //传递值
            preparedStatement.setInt(1,graProject.getId());
            preparedStatement.setString(2,graProject.getStuNumber());
            preparedStatement.setString(3,graProject.getClassName());
            preparedStatement.setString(4,graProject.getStuName());
            preparedStatement.setString(5,graProject.getProName());
            preparedStatement.setString(6,graProject.getType());
            preparedStatement.setString(7,graProject.getStaTime());
            preparedStatement.setString(8,graProject.getEndTime());
            preparedStatement.setString(9,graProject.getProTime());
            preparedStatement.setDouble(10,graProject.getScore());
            preparedStatement.setString(11,graProject.getTeacher());
            int i =preparedStatement.executeUpdate();
            return i;
        } catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDbcUtils.close(resultSet,prepared,conn);
        }
    }
//修改
public int UpdateGraProject(GraProject graProject){
    Connection conn=null;
    PreparedStatement prepared=null;
    ResultSet resultSet=null;
    try {
        conn = getConnection();
        //修改操作
        String sql ="update  graproject set stuNumber=?,className=?,stuName=?,proName=?,type=?,staTime=?,endTime=?,proTime=?,score=?,teacher=? where id=?";
        prepared=conn.prepareStatement(sql);
        prepared.setInt(11,graProject.getId());
        prepared.setString(1,graProject.getStuNumber());
        prepared.setString(2,graProject.getClassName());
        prepared.setString(3,graProject.getStuName());
        prepared.setString(4,graProject.getProName());
        prepared.setString(5,graProject.getType());
        prepared.setString(6,graProject.getStaTime());
        prepared.setString(7,graProject.getEndTime());
        prepared.setString(8,graProject.getProTime());
        prepared.setDouble(9,graProject.getScore());
        prepared.setString(10,graProject.getTeacher());
        int i =prepared.executeUpdate();
        return i;
        //传递值
    } catch (SQLException e){
        throw new RuntimeException(e);
    }finally {
        JDbcUtils.close(resultSet,prepared,conn);
    }
}
   //删除
    public GraProject deleteById(String id){
        Connection conn=null;
        PreparedStatement prepared=null;
        ResultSet resultSet=null;
        GraProject g=null;
        try {
            conn = getConnection();

            //删除操作
            String sql ="delete from graproject where id = ?";
            //传递值
            prepared=conn.prepareStatement(sql);
           prepared.setString(1,id);
           prepared.executeUpdate();


        } catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDbcUtils.close(resultSet,prepared,conn);
        }
        return g;
    }
    //用id查找数据
    public GraProject getGraProjectByTd(String id){
        Connection conn=null;
        PreparedStatement prepared=null;
        ResultSet resultSet=null;
        try {
            conn = getConnection();
            String sql ="select * from graproject where id=?";
            prepared=conn.prepareStatement(sql);
            prepared.setString(1,id);
            resultSet =prepared.executeQuery();
            if(resultSet.next()){
                GraProject gra=new GraProject(
                        resultSet.getInt("id"),
                        resultSet.getString("stuNumber"),
                        resultSet.getString("className"),
                        resultSet.getString("stuName"),
                        resultSet.getString("proName"),
                        resultSet.getString("type"),
                        resultSet.getString("staTime"),
                        resultSet.getString("endTime"),
                        resultSet.getString("proTime"),
                        resultSet.getDouble("score"),
                        resultSet.getString("teacher")
                );
                return gra;
            }else {
                return null;
            }
    } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<GraProject> SelectById(String id) {
        Connection conn=null;
        PreparedStatement prepared=null;
        List<GraProject> graProjectList=new ArrayList<>();
        ResultSet resultSet=null;
        try {
            conn = getConnection();
            String sql ="select * from graproject where id=?";
            prepared=conn.prepareStatement(sql);
            prepared.setString(1,id);
            resultSet =prepared.executeQuery();
            while (resultSet.next()){
                GraProject g=new GraProject();
                g.setId(resultSet.getInt("id"));
                g.setStuNumber(resultSet.getString("stuNumber"));
                g.setClassName(resultSet.getString("className"));
                g.setStuName(resultSet.getString("stuName"));
                g.setProName(resultSet.getString("proName"));
                g.setType(resultSet.getString("type"));
                g.setStaTime(resultSet.getString("staTime"));
                g.setEndTime(resultSet.getString("endTime"));
                g.setProTime(resultSet.getString("proTime"));
                g.setScore(resultSet.getDouble("score"));
                g.setTeacher(resultSet.getString("teacher"));
                graProjectList.add(g);
            }

        } catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDbcUtils.close(resultSet,prepared,conn);
        }
        return graProjectList;
    }

    public List<GraProject> SelectByStuName(String stuName) {
        Connection conn=null;
        PreparedStatement prepared=null;
        List<GraProject> graProjectList=new ArrayList<>();
        ResultSet resultSet=null;
        try {
            conn = getConnection();
            String sql ="select * from graproject where stuName=?";
            prepared=conn.prepareStatement(sql);
            prepared.setString(1,stuName);
            resultSet =prepared.executeQuery();
            while (resultSet.next()){
                GraProject g=new GraProject();
                g.setId(resultSet.getInt("id"));
                g.setStuNumber(resultSet.getString("stuNumber"));
                g.setClassName(resultSet.getString("className"));
                g.setStuName(resultSet.getString("stuName"));
                g.setProName(resultSet.getString("proName"));
                g.setType(resultSet.getString("type"));
                g.setStaTime(resultSet.getString("staTime"));
                g.setEndTime(resultSet.getString("endTime"));
                g.setProTime(resultSet.getString("proTime"));
                g.setScore(resultSet.getDouble("score"));
                g.setTeacher(resultSet.getString("teacher"));
                graProjectList.add(g);
            }

        } catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDbcUtils.close(resultSet,prepared,conn);
        }
        return graProjectList;
    }

    public List<GraProject> SelectByTeacher(String teacher) {
        Connection conn=null;
        PreparedStatement prepared=null;
        List<GraProject> graProjectList=new ArrayList<>();
        ResultSet resultSet=null;
        try {
            conn = getConnection();
            String sql ="select * from graproject where teacher=?";
            prepared=conn.prepareStatement(sql);
            prepared.setString(1,teacher);
            resultSet =prepared.executeQuery();
            while (resultSet.next()){
                GraProject g=new GraProject();
                g.setId(resultSet.getInt("id"));
                g.setStuNumber(resultSet.getString("stuNumber"));
                g.setClassName(resultSet.getString("className"));
                g.setStuName(resultSet.getString("stuName"));
                g.setProName(resultSet.getString("proName"));
                g.setType(resultSet.getString("type"));
                g.setStaTime(resultSet.getString("staTime"));
                g.setEndTime(resultSet.getString("endTime"));
                g.setProTime(resultSet.getString("proTime"));
                g.setScore(resultSet.getDouble("score"));
                g.setTeacher(resultSet.getString("teacher"));
                graProjectList.add(g);
            }

        } catch (SQLException e){
            throw new RuntimeException(e);
        }finally {
            JDbcUtils.close(resultSet,prepared,conn);
        }
        return graProjectList;
    }

    // 判断id是否存在
    public boolean pan(int i) throws SQLException{
        Connection connection= getConnection();
        String sql = "select id from graproject where id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1,i);
        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()){
            return true;
        }
        else{
            return  false;
        }

    }



}
