package com.lqs.demo.dao;

import com.lqs.demo.entity.User;
import com.lqs.demo.utils.JDbcUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class UserDao {
    private JdbcTemplate template=new JdbcTemplate(JDbcUtils.getDataSource());

    public User login(User loginUser){
        try{
        String sql="select * from gra_users where username=? and password=?";
        User user=template.queryForObject(sql,new BeanPropertyRowMapper<User>(User.class),
                loginUser.getUsername(),loginUser.getPassword());
        return user;
    }catch (DataAccessException e){
            e.printStackTrace();
            return null;
        }
    }

}
