package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbHelper {

	public static String driver = "com.mysql.jdbc.Driver";
	public static String url = "jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
	public static String username = "root";
	public static String password = "cm1582854067";
	public static Connection connection;

	public static Connection getConnection() {
		if(connection == null) {
			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, username, password);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return connection;
	}
	
	public static void close(PreparedStatement pst,ResultSet rst) {
		if (pst != null) {
			try {
				pst.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (rst != null) {
			try {
				rst.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
