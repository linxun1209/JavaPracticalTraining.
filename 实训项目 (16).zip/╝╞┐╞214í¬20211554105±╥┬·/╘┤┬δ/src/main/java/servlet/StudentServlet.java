package servlet; /**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/12 0012 21:08
 * @Description:${description}
 */

import dao.StudentDao;
import model.Student;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "StudentServlet", value = "/StudentServlet")
public class StudentServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置请求编码格式
        request.setCharacterEncoding("utf-8");
        //设置响应类别
        response.setContentType("text/html;charset=utf-8");
        StudentDao studentDao = new StudentDao();
        List<Student> studentList = studentDao.getAllStudent();
        //将值添加到request作用域中
        request.setAttribute("studentList", studentList);
        //转发
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }
}
