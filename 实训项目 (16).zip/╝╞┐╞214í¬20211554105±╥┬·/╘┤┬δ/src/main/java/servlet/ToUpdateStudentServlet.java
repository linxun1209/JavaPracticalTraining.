package servlet; /**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/13 0013 19:05
 * @Description:${description}
 */

import dao.StudentDao;
import model.Student;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ToUpdateStudentServlet", value = "/ToUpdateStudentServlet")
public class ToUpdateStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        String studentNo = request.getParameter("studentNo");
        StudentDao studentDao = new StudentDao();
        Student student = studentDao.getStudent(studentNo);
        request.setAttribute("studentList", student);
        request.getRequestDispatcher("update.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
