package servlet; /**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/12 0012 21:43
 * @Description:${description}
 */

import dao.StudentDao;
import model.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "AddStudentServlet", value = "/AddStudentServlet")
public class AddStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置请求编码格式
        request.setCharacterEncoding("utf-8");
        //设置响应类别
        response.setContentType("text/html;charset=utf-8");
        String studentNo = request.getParameter("studentNo");
        String name = request.getParameter("name");
        String sex = request.getParameter("sex");
        String age = request.getParameter("age");
        String banji = request.getParameter("banji");
        String bornDate = request.getParameter("bornDate");
        String phone = request.getParameter("phone");
        String major = request.getParameter("major");
        String faculty = request.getParameter("faculty");
        String address = request.getParameter("address");
        Student student = new Student();
        student.setStudentNo(studentNo);
        student.setName(name);
        student.setSex(sex);
        student.setAge(Integer.parseInt(age));
        student.setBanji(banji);
        student.setBornDate(bornDate);
        student.setPhone(phone);
        student.setMajor(major);
        student.setFaculty(faculty);
        student.setAddress(address);
        StudentDao studentDao = new StudentDao();
        boolean flag = studentDao.addStudent(student);
        if (flag) {
            System.out.println("添加学生成功");
            request.getSession().setAttribute("message", "添加学生成功！");
            request.getRequestDispatcher("StudentServlet").forward(request, response);
        } else {
            System.out.println("添加学生失败");
            request.getRequestDispatcher("add.jsp").forward(request, response);
            request.getSession().setAttribute("message", "添加学生失败！");
        }
    }

}

