package servlet;
/**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/13 0013 15:26
 * @Description:${description}
 */

import dao.StudentDao;
import model.Student;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "UpdateStudentServlet", value = "/UpdateStudentServlet")
public class UpdateStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置请求编码格式
        request.setCharacterEncoding("utf-8");
        //设置响应类别
        response.setContentType("text/html;charset=utf-8");
        String studentNo = request.getParameter("studentNo");
        String name = request.getParameter("name");
        String sex = request.getParameter("sex");
        String age = request.getParameter("age");
        String banji = request.getParameter("banji");
        String bornDate = request.getParameter("bornDate");
        String phone = request.getParameter("phone");
        String major = request.getParameter("major");
        String faculty = request.getParameter("faculty");
        String address = request.getParameter("address");
        Student student = new Student();
        System.out.println(student);
        student.setStudentNo(studentNo);
        student.setName(name);
        student.setSex(sex);
        student.setAge(Integer.parseInt(age));
        student.setBanji(banji);
        student.setBornDate(bornDate);
        student.setPhone(phone);
        student.setMajor(major);
        student.setFaculty(faculty);
        student.setAddress(address);
        StudentDao studentDao = new StudentDao();
        boolean flag = studentDao.updateStudent(student);
        if (flag) {
            response.sendRedirect("StudentServlet");
        } else {
            response.sendRedirect("ToUpdateStudentServlet");
        }
    }
}
