/*
 Navicat Premium Data Transfer

 Source Server         : local2
 Source Server Type    : MySQL
 Source Server Version : 80033
 Source Host           : localhost:3306
 Source Schema         : test

 Target Server Type    : MySQL
 Target Server Version : 80033
 File Encoding         : 65001

 Date: 09/06/2023 11:21:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `studentNo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '学号',
  `name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '姓名',
  `sex` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '性别',
  `age` int NULL DEFAULT NULL COMMENT '年龄',
  `banji` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '班级',
  `bornDate` date NULL DEFAULT NULL COMMENT '出生日期',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `major` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '专业',
  `faculty` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '院系',
  `address` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`studentNo`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('145895', '王五', '女', 25, '20本物联网专业', '2023-02-25', '15789456', '汽车维修', '城市建设学院', '广东深圳');
INSERT INTO `student` VALUES ('202299771278', '林志能', '男', 20, '20本软件工程7班', '2023-01-06', '15007063770', '软件工程', '信息工程学院', '湖南长沙');
INSERT INTO `student` VALUES ('2022997712782', '小红', '女', 23, '22本大数据8班', '2023-03-13', '1579', '大数据', '人工智能学院', '黑龙江哈尔滨');
INSERT INTO `student` VALUES ('202299771279', '张三', '男', 22, '22本大数据8班', '2023-03-08', '1579', '软件技术', '信息工程学院', '湖南长沙');
INSERT INTO `student` VALUES ('202299771589', '张三', '男', 20, '18专会计1班', '2023-03-10', '55', '软件技术', '信息工程学院', '湖北武汉');
INSERT INTO `student` VALUES ('23232', '初六', '男', 20, '18专会计1班', '2023-03-04', '110', '软件技术', '信息工程学院', '黑龙江哈尔滨');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `password` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (4, 'admin', '123');
INSERT INTO `user` VALUES (5, 'admin', '123');
INSERT INTO `user` VALUES (6, 'lzn', '1');

SET FOREIGN_KEY_CHECKS = 1;
