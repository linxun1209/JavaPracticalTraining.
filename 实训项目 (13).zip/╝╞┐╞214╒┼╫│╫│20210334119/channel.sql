/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80032 (8.0.32)
 Source Host           : localhost:3306
 Source Schema         : channel

 Target Server Type    : MySQL
 Target Server Version : 80032 (8.0.32)
 File Encoding         : 65001

 Date: 09/06/2023 10:19:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `stuId` int NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sex` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `class` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `chinese` double NULL DEFAULT 0,
  `math` double NULL DEFAULT 0,
  `english` double NULL DEFAULT 0,
  `sum` double NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `stuId`(`stuId` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES (1, 202103310, '张山', '男', 'A1', 98, 98, 98, 294);
INSERT INTO `score` VALUES (2, 202103311, '蛇毒', '女', 'A2', 96, 90, 100, 286);
INSERT INTO `score` VALUES (3, 202103312, '撒旦', '女', 'B2', 93, 96, 99, 292);
INSERT INTO `score` VALUES (4, 202103313, '阿斯顿', '女', 'C1', 99, 98, 99, 296);
INSERT INTO `score` VALUES (5, 202103314, '艾斯德斯', '男', 'C5', 100, 100, 100, 300);
INSERT INTO `score` VALUES (6, 202103316, '李四', '男', 'A1', 90, 100, 96, 286);
INSERT INTO `score` VALUES (7, 202103317, '撒的', '女', 'A1', 98, 99, 98, 295);
INSERT INTO `score` VALUES (8, 202103318, '阿瑟东', '男', 'A1', 100, 100, 100, 300);
INSERT INTO `score` VALUES (9, 202103319, '阿迪斯', '男', 'C1', 96, 93, 99, 292);
INSERT INTO `score` VALUES (10, 202103320, '阿瑟东', '男', 'B1', 99, 98, 96, 293);
INSERT INTO `score` VALUES (11, 202103321, '梵蒂冈', '女', 'B2', 98, 98, 99, 295);
INSERT INTO `score` VALUES (12, 202103322, '撒旦', '女', 'A2', 100, 100, 100, 300);
INSERT INTO `score` VALUES (13, 202103323, '高峰', '男', 'A3', 99, 99, 99, 297);
INSERT INTO `score` VALUES (14, 202103324, '东方', '男', 'A1', 98, 98, 98, 294);
INSERT INTO `score` VALUES (15, 202103325, '奥迪', '女', 'A1', 98, 98, 100, 296);
INSERT INTO `score` VALUES (16, 202103326, '大成', '男', 'B2', 99, 99, 99, 297);
INSERT INTO `score` VALUES (17, 202103327, '萨驰', '女', 'C3', 96, 97, 98, 291);
INSERT INTO `score` VALUES (18, 2023095784, '凯莎', '女', 'A2', 100, 100, 100, 100);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `stu_name` int NOT NULL,
  `stu_password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `stu_name`(`stu_name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1, 202103310, '123');
INSERT INTO `student` VALUES (2, 202103311, '1234');
INSERT INTO `student` VALUES (3, 202103312, '12345');
INSERT INTO `student` VALUES (4, 202103313, '12345');
INSERT INTO `student` VALUES (5, 202103314, '12345');
INSERT INTO `student` VALUES (6, 202103315, '12345');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `th_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `th_password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `th_name`(`th_name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES (1, 'zzz', '123');
INSERT INTO `teacher` VALUES (2, 'xxxx', '123456');
INSERT INTO `teacher` VALUES (3, 'ccccc', '12345');

SET FOREIGN_KEY_CHECKS = 1;
