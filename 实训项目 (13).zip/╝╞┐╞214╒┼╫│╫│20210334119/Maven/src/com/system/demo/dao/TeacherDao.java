package com.system.demo.dao;

import com.system.demo.entity.StudentScore;
import com.system.demo.entity.TLogin;
import com.system.demo.utils.JdbcUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TeacherDao {
    public static TeacherDao teacherDao= null;
    private TeacherDao(){
    }


    public static TeacherDao getInstance(){
        if(teacherDao==null){
            synchronized (StudentDao.class){
                if (teacherDao==null){
                    teacherDao=new TeacherDao();
                }
            }
        }
        return teacherDao;
    }



    //查询全部
    public List<StudentScore> selectAllScore(){
        Connection connection = null;
        PreparedStatement prepared = null;
        ResultSet resultSet = null;
        List<StudentScore> studentScoresList = new ArrayList<>();
        try {
            connection = JdbcUtils.getConnection();
            String sql = "select * from score";
            prepared = connection.prepareStatement(sql);
            resultSet = prepared.executeQuery();
            while (resultSet.next()){
                StudentScore s = new StudentScore();
                s.setId(resultSet.getInt("id"));
                s.setStuId(resultSet.getInt("stuId"));
                s.setName(resultSet.getString("name"));
                s.setSex(resultSet.getString("sex"));
                s.setClasses(resultSet.getString("class"));
                s.setChinese(resultSet.getDouble("chinese"));
                s.setMath(resultSet.getDouble("math"));
                s.setEnglish(resultSet.getDouble("english"));
                s.setSum(resultSet.getDouble("sum"));
                System.out.println();
                studentScoresList.add(s);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet,prepared,connection);

        }
        return studentScoresList;
    }


    //添加学生成绩
    public String addScore(StudentScore s){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String row = null;
        try {
            connection = JdbcUtils.getConnection();

            String sql0 = "select * from score where stuId = ？";

            String sql = "insert into score (stuId,name,sex,class,chinese,math,english,sum) values (?,?,?,?,?,?,?,?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,s.getStuId());
            preparedStatement.setString(2,s.getName());
            preparedStatement.setString(3,s.getSex());
            preparedStatement.setString(4,s.getClasses());
            preparedStatement.setDouble(5,s.getChinese());
            preparedStatement.setDouble(6,s.getMath());
            preparedStatement.setDouble(7,s.getEnglish());
            preparedStatement.setDouble(8,s.getSum());
            preparedStatement.executeUpdate();
            String sql1 = "set @i = 0";
            preparedStatement = connection.prepareStatement(sql1);
            preparedStatement.executeUpdate();
            String sql2 = "update score set id = (@i:=@i+1) where id!=0 ";
            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.executeUpdate();
            row = "添加成功";

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet, preparedStatement, connection);
        }
        return row;
    }

    public String updateScore(StudentScore s){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = JdbcUtils.getConnection();
            String sql = "update score set name=? ,  sex=? , class=? , chinese=? , math=? , english=? ,sum = ?  where stuId=? ";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,s.getName());
            preparedStatement.setString(2,s.getSex());
            preparedStatement.setString(3,s.getClasses());
            preparedStatement.setDouble(4,s.getChinese());
            preparedStatement.setDouble(5,s.getMath());
            preparedStatement.setDouble(6,s.getEnglish());
            preparedStatement.setDouble(7,s.getSum());
            preparedStatement.setDouble(8,s.getStuId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet,preparedStatement,connection);
        }
        return "修改成功";
    }

    public String DeleteByScore(int stuId){

        StudentScore studentScore = new StudentScore();
        studentScore.setStuId(stuId);

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = JdbcUtils.getConnection();
            String sql = "delete from score where stuId = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, studentScore.getStuId());
            preparedStatement.executeUpdate();

            //删除成绩后对编号进行重新排序
            String sql1 = "set @i = 0";
            preparedStatement = connection.prepareStatement(sql1);
            preparedStatement.executeUpdate();
            String sql2 = "update score set id = (@i:=@i+1) where id!=0 ";
            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.executeUpdate();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet,preparedStatement,connection);
        }
        return "删除成功";
    }
}
