package com.system.demo.dao;

import com.system.demo.entity.SLogin;
import com.system.demo.entity.StudentScore;
import com.system.demo.utils.JdbcUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class StudentDao {

    public static StudentDao studentDao= null;

    private StudentDao(){
    }


    public static StudentDao getInstance(){
        if(studentDao==null){
            synchronized (StudentDao.class){
                if (studentDao==null){
                    studentDao=new StudentDao();
                }
            }
        }
        return studentDao;
    }


    public List<StudentScore> selectId(int stuId){
        Connection connection = null;
        PreparedStatement prepared = null;
        ResultSet resultSet = null;
        List<StudentScore> studentScoresList = new ArrayList<>();
        try {
            connection = JdbcUtils.getConnection();
            String sql = "select * from score where stuId=?";
            prepared = connection.prepareStatement(sql);
            prepared.setInt(1,stuId);

            resultSet = prepared.executeQuery();

            while (resultSet.next()){
                StudentScore s = new StudentScore();
                s.setId(resultSet.getInt("id"));
                s.setStuId(resultSet.getInt("stuId"));
                s.setName(resultSet.getString("name"));
                s.setSex(resultSet.getString("sex"));
                s.setClasses(resultSet.getString("class"));
                s.setChinese(resultSet.getDouble("chinese"));
                s.setMath(resultSet.getDouble("math"));
                s.setEnglish(resultSet.getDouble("english"));
                s.setSum(resultSet.getDouble("sum"));
                System.out.println();
                studentScoresList.add(s);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet,prepared,connection);

        }
        return studentScoresList;
    }

    public List<StudentScore> selectClass(String classes){
        Connection connection = null;
        PreparedStatement prepared = null;
        ResultSet resultSet = null;
        List<StudentScore> studentScoresList = new ArrayList<>();
        try {
            connection = JdbcUtils.getConnection();
            String sql = "select * from score where class=?";
            prepared = connection.prepareStatement(sql);
            prepared.setString(1,classes);

            resultSet = prepared.executeQuery();

            while (resultSet.next()){
                StudentScore s = new StudentScore();
                s.setId(resultSet.getInt("id"));
                s.setStuId(resultSet.getInt("stuId"));
                s.setName(resultSet.getString("name"));
                s.setSex(resultSet.getString("sex"));
                s.setClasses(resultSet.getString("class"));
                s.setChinese(resultSet.getDouble("chinese"));
                s.setMath(resultSet.getDouble("math"));
                s.setEnglish(resultSet.getDouble("english"));
                s.setSum(resultSet.getDouble("sum"));
                System.out.println();
                studentScoresList.add(s);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet,prepared,connection);

        }
        return studentScoresList;
    }



    public List<StudentScore> selectName(String name){
        Connection connection = null;
        PreparedStatement prepared = null;
        ResultSet resultSet = null;
        List<StudentScore> studentScoresList = new ArrayList<>();
        try {
            connection = JdbcUtils.getConnection();
            String sql = "select * from score where name=?";
            prepared = connection.prepareStatement(sql);
            prepared.setString(1,name);

            resultSet = prepared.executeQuery();

            while (resultSet.next()){
                StudentScore s = new StudentScore();
                s.setId(resultSet.getInt("id"));
                s.setStuId(resultSet.getInt("stuId"));
                s.setName(resultSet.getString("name"));
                s.setSex(resultSet.getString("sex"));
                s.setClasses(resultSet.getString("class"));
                s.setChinese(resultSet.getDouble("chinese"));
                s.setMath(resultSet.getDouble("math"));
                s.setEnglish(resultSet.getDouble("english"));
                s.setSum(resultSet.getDouble("sum"));
                System.out.println();
                studentScoresList.add(s);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet,prepared,connection);
        }
        return studentScoresList;
    }
}
