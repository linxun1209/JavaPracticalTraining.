package com.system.demo.dao;


import com.system.demo.entity.StudentScore;
import com.system.demo.entity.TLogin;
import com.system.demo.utils.JdbcUtils;

import javax.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class TCheck{

    public static TCheck tCheck= null;
    private TCheck(){
    }
    public static TCheck getInstance(){
        if(tCheck==null){
            synchronized (TCheck.class){
                if (tCheck==null){
                    tCheck=new TCheck();
                }
            }
        }
        return tCheck;
    }

    // 数据库连接和查询操作可以封装在 StudentDAO 类中，这里只做简单演示
    public Integer check1(TLogin t){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int i = 0;
        try {
            connection = JdbcUtils.getConnection();
            String sql = "select * from teacher where th_name=? and th_password = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,t.getTh_name());
            preparedStatement.setString(2,t.getTh_password());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                TLogin tLogin = new TLogin();
                tLogin.setTh_name(resultSet.getString("th_name"));
                tLogin.setTh_password(resultSet.getString("th_password"));
                i=1;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JdbcUtils.close(resultSet, preparedStatement, connection);
        }
        return i;
    }
}
