package com.system.demo.web;

import com.system.demo.dao.StudentDao;
import com.system.demo.dao.TeacherDao;
import com.system.demo.entity.StudentScore;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/score")
public class TeacherSelect extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        TeacherDao teacherDao = TeacherDao.getInstance();
        List<StudentScore> scores = teacherDao.selectAllScore();
        req.setAttribute("scoreList",scores);

        RequestDispatcher requestDispatcher = req.getRequestDispatcher("/type.jsp");
        requestDispatcher.forward(req,resp);
    }
}
