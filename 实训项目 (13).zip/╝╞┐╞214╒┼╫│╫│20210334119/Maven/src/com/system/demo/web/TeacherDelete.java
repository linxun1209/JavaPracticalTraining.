package com.system.demo.web;

import com.system.demo.dao.TeacherDao;
import com.system.demo.entity.StudentScore;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/score/delete")
public class TeacherDelete extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF8");

        String stuId = req.getParameter("stuId");
        StudentScore studentScore = new StudentScore();
        studentScore.setStuId(Integer.parseInt(stuId));


        TeacherDao teacherDao = TeacherDao.getInstance();
        String row = teacherDao.DeleteByScore(studentScore.getStuId());


        req.getSession().setAttribute("msg","删除成功~!");
        resp.sendRedirect(req.getServletContext().getContextPath()+"/score");

    }
}
