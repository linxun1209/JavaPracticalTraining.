package com.system.demo.web;

import com.system.demo.dao.TCheck;
import com.system.demo.dao.TeacherDao;
import com.system.demo.entity.StudentScore;
import com.system.demo.entity.TLogin;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/score/tcheck")
public class TeacherCheck extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        req.setCharacterEncoding("UTF8");

        String th_name = req.getParameter("th_name");
        String th_password = req.getParameter("th_password");

        TLogin tLogin = new TLogin();
        tLogin.setTh_name(th_name);
        tLogin.setTh_password(th_password);


        TCheck tCheck= TCheck.getInstance();
        int i = tCheck.check1(tLogin);

        if(i==1){
            RequestDispatcher requestDispatcher = req.getRequestDispatcher("/index.jsp");
            requestDispatcher.forward(req,resp);
        }else {
            RequestDispatcher requestDispatcher = req.getRequestDispatcher("/loginError.jsp");
            requestDispatcher.forward(req,resp);
        }

    }
}
