package com.system.demo.web;

import com.system.demo.dao.TeacherDao;
import com.system.demo.entity.StudentScore;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/score/add")
public class TeacherAdd extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF8");

        String stuId = req.getParameter("stuId");
        String name = req.getParameter("name");
        String sex = req.getParameter("sex");
        String classes = req.getParameter("classes");
        String chinese = req.getParameter("chinese");
        String math = req.getParameter("math");
        String english = req.getParameter("english");
        String sum = req.getParameter("sum");

        StudentScore studentScore = new StudentScore();
        studentScore.setStuId(Integer.parseInt(stuId));
        studentScore.setName(name);
        studentScore.setSex(sex);
        studentScore.setClasses(classes);
        studentScore.setChinese(Integer.parseInt(chinese));
        studentScore.setMath(Integer.parseInt(math));
        studentScore.setEnglish(Integer.parseInt(english));
        studentScore.setSum(Integer.parseInt(sum));



        TeacherDao teacherDao = TeacherDao.getInstance();
        String row = teacherDao.addScore(studentScore);

        req.getSession().setAttribute("msg","添加成功~!");
//        RequestDispatcher requestDispatcher = req.getRequestDispatcher("/score");
//        requestDispatcher.forward(req,resp);

        resp.sendRedirect(req.getServletContext().getContextPath()+"/score");
    }
}
