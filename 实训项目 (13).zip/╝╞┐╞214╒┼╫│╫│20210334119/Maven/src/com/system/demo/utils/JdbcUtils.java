package com.system.demo.utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import javax.sql.DataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
public class JdbcUtils {
    public static DataSource dataSource;
    static {
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream("E:\\idea\\idea1\\Maven\\src\\druid.properties"));
            dataSource= DruidDataSourceFactory.createDataSource(prop);
        }catch (IOException e){
            throw new RuntimeException(e);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    public static Connection getConnection() throws SQLException{
        return dataSource.getConnection();
    }

    public static  void close(ResultSet rs, PreparedStatement ps){
        close(rs,ps);
    }

    public static  void close(ResultSet rs, PreparedStatement ps,Connection conn){
        if(rs!=null){
            try{
                rs.close();
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }
    }
}