package com.system.demo.entity;

//老师登录

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class TLogin {
    private Integer id;
    private String th_name;
    private String th_password;
}
