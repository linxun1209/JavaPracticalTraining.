package com.system.demo.entity;

//学生登录

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class SLogin {
    private Integer id;
    private Integer stu_name;
    private String stu_password;
}
