package com.system.demo.entity;

//学生分数

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class StudentScore {
    private Integer id;
    private Integer stuId;
    private String name;
    private String sex;
    private String classes;
    private double chinese;
    private double math;
    private double english;
    private double sum;
}
