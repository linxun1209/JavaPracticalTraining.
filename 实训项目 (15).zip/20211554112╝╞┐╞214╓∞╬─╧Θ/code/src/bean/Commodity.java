package bean;


//包含行信息的类
public class Commodity {
    private String id;
    private String name;
    private String sex;
    private String grade;
    private String intime;
    private String home_id;
    private String bedhome_id;
    private String bed_id;

    public Commodity(){

    }

    public Commodity(String id, String name, String sex, String grade, String intime, String home_id, String bedhome_id, String bed_id) {
        this.id = id;
        this.name = name;
        this.sex = sex;
        this.grade = grade;
        this.intime = intime;
        this.home_id = home_id;
        this.bedhome_id = bedhome_id;
        this.bed_id = bed_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getIntime() {
        return intime;
    }

    public void setIntime(String intime) {
        this.intime = intime;
    }

    public String getHome_id() {
        return home_id;
    }

    public void setHome_id(String home_id) {
        this.home_id = home_id;
    }

    public String getBedhome_id() {
        return bedhome_id;
    }

    public void setBedhome_id(String bedhome_id) {
        this.bedhome_id = bedhome_id;
    }

    public String getBed_id() {
        return bed_id;
    }

    public void setBed_id(String bed_id) {
        this.bed_id = bed_id;
    }

    @Override
    public String toString() {
        return "Commodity{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", grade='" + grade + '\'' +
                ", intime='" + intime + '\'' +
                ", home_id='" + home_id + '\'' +
                ", bedhome_id='" + bedhome_id + '\'' +
                ", bed_id='" + bed_id + '\'' +
                '}';
    }
}
