package dao;

import bean.Commodity;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.DBHelper;

import java.sql.*;
import java.util.ArrayList;


/*
    通过图形化界界面生成的操作对数据库中的三个表进行操作
 */
public class CommodityDao {
    // QueryRunner是SQL语句的操作对象 用于执行SQL语句
    QueryRunner runner = new QueryRunner(); // 完成数据库的增删改查
    // 添加学生信息
    public void setCommodity1 (String id,String name,String sex,String grade) throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="insert into information (id,name,sex,grade) values (?,?,?,?); ";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,id,name,sex,grade);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }

    // 添加入住信息
    public void setCommodity2 (String id,String intime) throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="insert into time (id,intime) values (?,?); ";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,id,intime);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }

    // 添加具体房间信息
    public void setCommodity3 (String id,String home_id,String bedhome_id,String bed_id) throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="insert into home (id,home_id,bedhome_id,bed_id) values (?,?,?,?); ";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,id,home_id,bedhome_id,bed_id);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }


    // 将 商品 添加到 集合中，展示出来
    public ArrayList<Commodity>  getCommodity () throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        ArrayList <Commodity> data = new ArrayList<>();
        //主页面中的查询语句
        String sql2 = "select i.id,i.name,i.sex,i.grade,t.intime,h.home_id,h.bedhome_id," +
                "h.bed_id from information i , home h,time t where i.id=h.id and i.id = t.id";
        PreparedStatement preparedStatement = conn.prepareStatement(sql2);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            data.add(new Commodity(resultSet.getString(1),resultSet.getString(2)
                    ,resultSet.getString(3),resultSet.getString(4),
                    resultSet.getString(5),resultSet.getString(6),
                    resultSet.getString(7),resultSet.getString(8)));
        }
        return data;
    }

    // 删除学生信息
    public void delCommodity (long id)throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="delete from information where id=?";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,id);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }
    // 删除学生入住时间
    public void delCommodity1 (int id)throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="delete from time where id=?";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,id);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }
    // 删除入住房间信息
    public void delCommodity2 (int id)throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="delete from home where id=?";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,id);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }

    // 修改学生信息
    public void modCommodity (String id ,String name,String sex,String grade)throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="update information set name=?,sex=?,grade=?where id=?";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,name,sex,grade,id);

//        System.out.println(count);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }
    // 修改学生信息1
    public void modCommodity1 (String id ,String intime)throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="update time set intime=? where id=?";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,intime,id);

//        System.out.println(count);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }
    // 修改学生信息2
    public void modCommodity2 (String id ,String home_id,String bedhome_id,String bed_id)throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="update home set home_id=?,bedhome_id=?,bed_id=? where id=?";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,home_id,bedhome_id,bed_id,id);

//        System.out.println(count);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }


    //  修改的时候，根据 id 查 设置默认值
    public Commodity modfindCommodity1 (long id) throws SQLException {
        Connection con = DBHelper.getConnection();
        String sql3 = "select * from information where `id` =?";
        Commodity commodity = runner.query(con,sql3,new BeanHandler<Commodity>(Commodity.class),id);
        DBHelper.close(con);
        return commodity;
    }

    //  修改的时候，根据 id 查 设置默认值
    public Commodity modfindCommodity2 (long id) throws SQLException {
        Connection con = DBHelper.getConnection();
        String sql3 = "select * from time where `id` =?";
        Commodity commodity = runner.query(con,sql3,new BeanHandler<Commodity>(Commodity.class),id);
        DBHelper.close(con);
        return commodity;
    }

    //  修改的时候，根据 id 查 设置默认值
    public Commodity modfindCommodity3 (long id) throws SQLException {
        Connection con = DBHelper.getConnection();
        String sql3 = "select * from home where `id` =?";
        Commodity commodity = runner.query(con,sql3,new BeanHandler<Commodity>(Commodity.class),id);
        DBHelper.close(con);
        return commodity;
    }

    //  模糊 查找 。
    public ArrayList<Commodity> findCommodity(String text) throws SQLException {
//        "select * from information i , home h,time t where i.id=h.id and i.id = t.id
        Connection con = DBHelper.getConnection();
        ArrayList<Commodity> findgoods = new ArrayList<>();
//        String sql = "select i.id,i.name,i.sex,i.grade,h.intime,t.home_id,t.homebed_id,t.bed_id from information i , home h,time t where i.id=h.id and i.id = t.id and i.name like '%"+text+"'|| i.name like '"+text+"%'|| i.name like '%"+text+"%'||i.name ="+"'"+text+"'";
        String sql =  "select * from information i , home h,time t " +
                "where i.id=h.id and i.id = t.id and i.name = '"+text+"'";
        Statement preparedStatement = con.createStatement();
//        preparedStatement.setString(1,text);

        ResultSet resultSet = preparedStatement.executeQuery(sql);
        while (resultSet.next()) {
            findgoods.add(new Commodity(resultSet.getString(1),
                    resultSet.getString(2),resultSet.getString(3),
                    resultSet.getString(4),resultSet.getString(5),
                    resultSet.getString(6),resultSet.getString(7),
                    resultSet.getString(8)));
        }

        return findgoods;

    }

    public static void main(String[] args) throws SQLException {

//        System.out.println(new CommodityDao().modfindCommodity(5));
//        System.out.println(new CarDao().CarCommodity("张三"));

    }

}
