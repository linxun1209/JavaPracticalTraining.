package biz;

public class CommodityBiz {
}
