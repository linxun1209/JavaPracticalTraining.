package action;

import dao.CommodityDao;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;


@WebServlet(urlPatterns = "/ModSubmit")
public class ModSubmitCommodityServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();

        CommodityDao commodityDao = new CommodityDao();

        String temp = req.getParameter("mod");
        //int temp1 = 0;

        if (temp!=null) {
            //temp1=Integer.parseInt(temp);
            long temp1 = Long.valueOf(temp);
        }

        DiskFileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        String imgPath="";

        try {
            String s1 = null;
            String s2 = null;
            String s3 = null;
            String s4 = null;
            String s5 = null;
            String s6 = null;
            String s7 = null;
            String s8 = null;
            List<FileItem> list = upload.parseRequest(req);

            for (FileItem item : list) {

                if (item.isFormField()) {
                    switch (item.getFieldName()) {
                        case "id":
                            s1 = item.getString("utf-8");
                            break;
                        case "name":
                            s2 = item.getString("utf-8");
                            break;
                        case "sex":
                            s3 = item.getString("utf-8");
                            break;
                        case "grade":
                            s4 = item.getString("utf-8");
                            break;
                        case "intime":
                            s5 = item.getString("utf-8");
                            break;
                        case "home_id":
                            s6 = item.getString("utf-8");
                            break;
                        case "bedhome_id":
                            s7 = item.getString("utf-8");
                            break;
                        case "bed_id":
                            s8 = item.getString("utf-8");
                            break;
                    }
                }


                if (s1!=""&&s2!=""&&s3!=""&&s4!=""&&s5!=""&&s6!=""&&s7!=""&&s8!="" &&s1!=null&&
                        s2!=null&&s3!=null&&s4!=null&&s5!=null&&s6!=null&&s7!=null&&s8!=null) {

                    try {
                        commodityDao.modCommodity(s1,s2,s3,s4);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                    try {
                        commodityDao.modCommodity1(s1,s5);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }

                    try {
                        commodityDao.modCommodity2(s1,s6,s7,s8);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                    out.println("<script>alert('修改成功');location.href = 'index';</script>");
                }
            }
        } catch (FileUploadException e) {
            e.printStackTrace();
        }

    }
}
