package action;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import dao.CommodityDao;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.UploadContext;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;



@WebServlet("/release")
public class CommodityServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();

        DiskFileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        CommodityDao commodityDao = new CommodityDao();
        String imgPath="";

        try {
            String id ="";
            String name = "";
            String sex = "";
            String grade="";
            String intime ="";
            String home_id = "";
            String bedhome_id = "";
            String bed_id="";
            List<FileItem> list = upload.parseRequest(req);
            for (FileItem item : list) {
                if (item.isFormField()){
                    switch (item.getFieldName()){
                        case "id" :
                            id = item.getString("utf-8");
                            break;
                        case "name" :
                            name = item.getString("utf-8");
                            break;
                        case "sex" :
                            sex = item.getString("utf-8");
                            break;
                        case "grade" :
                            grade = item.getString("utf-8");
                            break;
                        case "intime" :
                            intime = item.getString("utf-8");
                            break;
                        case "home_id" :
                            home_id = item.getString("utf-8");
                            break;
                        case "bedhome_id" :
                            bedhome_id = item.getString("utf-8");
                            break;
                        case "bed_id" :
                            bed_id = item.getString("utf-8");
                            break;
                    }
                }


                if (id!=""&&name!=""&&sex!=""&&grade!=""&&
                        intime!=""&&home_id!=""&&bedhome_id!=""&&bed_id!="") {

                    commodityDao.setCommodity1(id,name,sex,grade);
                    commodityDao.setCommodity2(id,intime);
                    commodityDao.setCommodity3(id,home_id,bedhome_id,bed_id);

                    out.println("<script>alert('添加成功');location.href = 'index';</script>");
                }
            }
        } catch (FileUploadException | SQLException e) {
            e.printStackTrace();
        }
    }
}
