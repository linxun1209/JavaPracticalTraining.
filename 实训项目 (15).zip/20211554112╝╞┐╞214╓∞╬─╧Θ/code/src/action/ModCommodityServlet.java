package action;


import dao.CommodityDao;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.jws.WebService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

@WebServlet(urlPatterns="/indexmod")
public class ModCommodityServlet  extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();

        CommodityDao commodityDao = new CommodityDao();
        String temp = req.getParameter("mod");
        long temp1 = 0;

        if (temp!=null) {
            //temp1=Integer.parseInt(temp);
            temp1 = Long.valueOf(temp);
        }

        String method = req.getParameter("type");

        switch (method) {
            case "mod1":
                String s1 = null;
                String s2 = null;
                String s3 = null;
                String s4 = null;
                String s5 = null;
                String s6 = null;
                String s7 = null;
                String s8 = null;
//                System.out.println(temp1);
                try {
                    s1 = commodityDao.modfindCommodity1(temp1).getId();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s2 = commodityDao.modfindCommodity1(temp1).getName();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s3 = commodityDao.modfindCommodity1(temp1).getSex();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s4 = commodityDao.modfindCommodity1(temp1).getGrade();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s5 = commodityDao.modfindCommodity2(temp1).getIntime();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s6 = commodityDao.modfindCommodity3(temp1).getHome_id();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s7 = commodityDao.modfindCommodity3(temp1).getBedhome_id();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s8 = commodityDao.modfindCommodity3(temp1).getBed_id();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                req.setAttribute("id1", s1);
                req.setAttribute("name1", s2);
                req.setAttribute("sex1", s3);
                req.setAttribute("grade1",s4);
                req.setAttribute("intime1",s5);
                req.setAttribute("home_id1",s6);
                req.setAttribute("bedhome_id1",s7);
                req.setAttribute("bed_id1",s8);
                req.getRequestDispatcher("mod.jsp").forward(req, resp);

                break;
        }
    }
}