package biz;

import bean.Commodity;
import bean.User;
import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import dao.CommodityDao;
import dao.UserDao;

import java.sql.SQLException;

public class CommodityBiz {



}
