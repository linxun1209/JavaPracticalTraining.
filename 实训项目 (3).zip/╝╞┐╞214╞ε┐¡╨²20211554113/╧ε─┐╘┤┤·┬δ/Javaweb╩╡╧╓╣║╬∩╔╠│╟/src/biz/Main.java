package biz;

import java.sql.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mydemo3";
        String user = "root";
        String password = "zhubao";
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            BrandDao brandDao = new BrandDao(connection);
            // Query all brands
            List<Brand> brands = brandDao.queryBrand();
            for (Brand brand : brands) {
                System.out.println(brand);
            }
            // Update a brand
            Brand brandToUpdate = brands.get(0);
            brandToUpdate.setBrand_name("New Brand Name");;
            brandDao.updateBrand(brandToUpdate);
            // Delete a brand by ID
            Integer idToDelete = brands.get(1).getId();
            brandDao.deleteByBrandId(idToDelete);
            // Add a new brand
            Brand newBrand = new Brand();
            newBrand.setBrand_name("New Brand");
            newBrand.setCompany_name("New Company");
            newBrand.setOrdered(4);
            newBrand.setDescription("New Description");
            newBrand.setStatus(1);
            brandDao.addBrand(newBrand);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}