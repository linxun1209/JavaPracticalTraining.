package biz;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BrandDao {
    private Connection connection;

    public BrandDao(Connection connection) {
        this.connection = connection;
    }

    public List<Brand> queryBrand() throws SQLException {
        List<Brand> brands = new ArrayList<>();
        String query = "SELECT * FROM tb_brand";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                Brand brand = new Brand();
                brand.setId(resultSet.getInt("id"));
                brand.setBrand_name(resultSet.getString("brand_name"));
                brand.setCompany_name(resultSet.getString("company_name"));
                brand.setOrdered(resultSet.getInt("ordered"));
                brand.setDescription(resultSet.getString("description"));
                brand.setStatus(resultSet.getInt("status"));
                brands.add(brand);
            }
        }
        return brands;
    }

    public void updateBrand(Brand brand) throws SQLException {
        String update = "UPDATE tb_brand SET brand_name=?, company_name=?, ordered=?, description=?, status=? WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(update)) {
            statement.setString(1, brand.getBrand_name());
            statement.setString(2, brand.getCompany_name());
            statement.setInt(3, brand.getOrdered());
            statement.setString(4, brand.getDescription());
            statement.setInt(5, brand.getStatus());
            statement.setInt(6, brand.getId());
            statement.executeUpdate();
        }
    }

    public void deleteByBrandId(Integer id) throws SQLException {
        String delete = "DELETE FROM tb_brand WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(delete)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public void addBrand(Brand brand) throws SQLException {
        String insert = "INSERT INTO tb_brand (brand_name, company_name, ordered, description, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(insert)) {
            statement.setString(1, brand.getBrand_name());
            statement.setString(2, brand.getCompany_name());
            statement.setInt(3, brand.getOrdered());
            statement.setString(4, brand.getDescription());
            statement.setInt(5, brand.getStatus());
            statement.executeUpdate();
        }
    }
}