package dao;

import bean.User;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.DBHelper;

import java.sql.Connection;
import java.sql.SQLException;

public class UserDao {

    // QueryRunner是SQL语句的操作对象
    QueryRunner runner = new QueryRunner(); // 完成数据库的增删改查
    //  登录账号
    public User getUser (String name , String pwd) throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection  conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="select * from user where name=? and pwd=? ";
//        String sql="select * from user ";
        // 3.调用查询方法,将查询的数据封装成User对象
        User user = runner.query(conn,sql,new BeanHandler<User>(User.class),name,pwd);
        // 4.关闭连接对象
        DBHelper.close(conn);
        // 5.返回user
        return user;

    }

    //   注册账号
    public void setUser (String name , String pwd) throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection  conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="insert into user (name,pwd) values (?,?); ";
//        String sql ="select * from user";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,name,pwd);
        // 4.关闭连接对象
        DBHelper.close(conn);
        // 5.返回user
//        return user;

    }


    //   用来测试
    public static void main(String[] args) {
        User user = null;
        try {
            user = new UserDao().getUser("张三","123");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println(user);





    }




}
