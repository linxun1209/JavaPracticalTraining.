package dao;

import bean.Car;
import bean.Commodity;
import bean.User;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.DBHelper;

import java.sql.*;
import java.util.ArrayList;

public class CarDao {

    // QueryRunner是SQL语句的操作对象
    QueryRunner runner = new QueryRunner(); // 完成数据库的增删改查

    // 添加商品信息
    public void setCargoods (String name,String id,String amount) throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="insert into car (user_name,goods,amount) values (?,?,?); ";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,name,id,amount);
        // 4.关闭连接对象
        DBHelper.close(conn);

    }


    // 遍历 该用户 在 购物车 中加入了 什么商品

    public ArrayList<Car> CarCommodity(String text) throws SQLException {

        Connection con = DBHelper.getConnection();
        ArrayList<Car> cargoods = new ArrayList<>();
        String sql = "select g.id,g.name, g.price,g.introduce,g.img,c.amount from mydemo.commodity g,mydemo.car c WHERE g.id=c.goods and c.user_name=?";
        PreparedStatement preparedStatement = con.prepareStatement(sql);
        preparedStatement.setString(1,text);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){

            cargoods.add(new Car(resultSet.getInt(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6)));
        }
        return cargoods;

    }

    // 下架购物车商品
    public void delCar (String id,String name)throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="delete from car where user_name=?&&goods=?";
        // 3.调用查询方法,将查询的数据封装成User对象
        int count = runner.update(conn,sql,name,id);
        // 4.关闭连接对象
        DBHelper.close(conn);
    }


    //  判断购物车 是否有这个商品
    public Car getCar (String name , String id) throws SQLException {
        // 1.调用DBHelper获取连接对象
        Connection  conn = DBHelper.getConnection();
        // 2.准备执行的sql语句
        String sql="select * from car where user_name=? and goods=? ";
//        String sql="select * from user ";
        // 3.调用查询方法,将查询的数据封装成User对象
        Car car = runner.query(conn,sql,new BeanHandler<Car>(Car.class),name,id);
        // 4.关闭连接对象
        DBHelper.close(conn);
        // 5.返回user
        return car;

    }







}
