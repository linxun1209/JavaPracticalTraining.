package action;

import java.time.LocalTime;
//  根据不同时间段，显示不同的问候语
public class Greeting {
    public static String getGreeting() {
        LocalTime now = LocalTime.now();
        String greeting = "";
        if (now.isBefore(LocalTime.NOON)) {
            greeting = "早上好！";
        } else if (now.isBefore(LocalTime.of(18, 0))) {
            greeting = "下午好！";
        } else {
            greeting = "晚上好！";
        }
        return greeting;
    }
}