package action;

import bean.Commodity;
import biz.CommodityBiz;
import dao.CommodityDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

@WebServlet(urlPatterns = "/index")
public class ShowServlet extends HttpServlet {

    CommodityBiz commodityBiz = new CommodityBiz();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);

}

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        HttpSession session = req.getSession();
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();



        CommodityDao commodityDao =new CommodityDao();


        String temp = req.getParameter("id");

        if (temp!=null){
            int temp1 = Integer.parseInt(temp);
            try {
                commodityDao.delCommodity(temp1);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        try {
            req.setAttribute("Arraylist",  commodityDao.getCommodity());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        req.getRequestDispatcher("index.jsp").forward(req, resp);



    }



}
