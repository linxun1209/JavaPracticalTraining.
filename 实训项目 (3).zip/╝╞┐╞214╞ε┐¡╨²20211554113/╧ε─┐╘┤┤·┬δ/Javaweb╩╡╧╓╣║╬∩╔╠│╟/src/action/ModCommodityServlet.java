package action;


import dao.CommodityDao;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.jws.WebService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

@WebServlet(urlPatterns="/indexmod")
public class ModCommodityServlet  extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        doPost(req, resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        HttpSession session = req.getSession();
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();

        CommodityDao commodityDao = new CommodityDao();
        String temp = req.getParameter("mod");
        int temp1 = 0;

        if (temp!=null) {
            temp1=Integer.parseInt(temp);
        }

        String method = req.getParameter("type");

        switch (method) {
            case "mod1":

                String s1 = null;
                String s2 = null;
                String s3 = null;
                String s4 = null;
                try {
                    s1 = commodityDao.modfindCommodity(temp1).getName();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s2 = commodityDao.modfindCommodity(temp1).getPrice();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s3 = commodityDao.modfindCommodity(temp1).getIntroduce();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                try {
                    s4 = commodityDao.modfindCommodity(temp1).getImg();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                req.setAttribute("name1", s1);
                req.setAttribute("price1", s2);
                req.setAttribute("introduce1", s3);
                req.setAttribute("id1",temp1);
                req.setAttribute("img1",s4);
                req.getRequestDispatcher("mod.jsp").forward(req, resp);

                break;



        }


    }

}