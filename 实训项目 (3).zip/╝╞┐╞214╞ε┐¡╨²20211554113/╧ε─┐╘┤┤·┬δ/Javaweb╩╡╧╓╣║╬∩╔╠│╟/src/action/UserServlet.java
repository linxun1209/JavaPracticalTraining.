package action;

import bean.User;
import biz.UserBiz;
import dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;


@WebServlet("/user.let")
public class UserServlet extends HttpServlet {

    // 构建UserBiz的对象
    UserBiz userBiz = new UserBiz();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    /**
     * /user.let?type=login 登录  /:项目的根目录--》web
     * web
     *   |-login.html
     *   |-user.let?type = login
     *   |-index.jsp
     * /user.let?type=exit  安全退出
     * /user.let?type=modifyPwd 修改密码
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();

        //1.判读用户请求的类型为login
        String method = req.getParameter("type");
        switch (method) {
            case "login":
                // 从 login.html中 拿 账号，密码等数据
                String name = req.getParameter("name");
                String pwd = req.getParameter("pwd");

                //  调用UserBiz的getUser方法，根据 网页中 输入的账号密码，获取相应对象
                User user = userBiz.getUser(name,pwd);

                 //判断 获取到的对象是否为 null;
                 if (user == null) {
                     System.out.println(user);
                     out.println("<script>alert('用户名或密码不存在');location.href = 'login.html';</script>");
                 }else {

                     session.setAttribute("user",user);//user-->Object
                     out.println("<script>alert('登录成功');location.href='/index';</script>");
                 }

                 break;
            case "register" :

                // 从 login.html中 拿 账号，密码等数据
                String name1 = req.getParameter("name");
                String pwd1 = req.getParameter("pwd");
                UserDao userDao = new UserDao();
                try {
                    userDao.setUser(name1,pwd1);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                out.println("<script>alert('注册成功');location.href = 'login.html';</script>");
                break;

        }



    }


}
