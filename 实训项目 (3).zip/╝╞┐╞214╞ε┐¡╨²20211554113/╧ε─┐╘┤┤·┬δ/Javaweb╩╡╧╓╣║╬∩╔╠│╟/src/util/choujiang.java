package util;

import java.util.ArrayList;
import java.util.Random;

public class choujiang {
    public static void main(String[] args) {
        String [] s = {"彩妆卡","药品卡","运动卡","农具卡","书籍卡","办公卡","护肤卡","文玩卡","家居卡","食品卡","潮玩卡","饮料卡","母婴卡",
                "箱包卡","宠物卡","五金卡","户外卡","植物卡","数码卡","厨具卡","床品卡","出行卡","灯具卡","鞋履卡","洗护卡","节庆卡","茶香卡",
                "美发卡","餐具卡","配饰卡","服饰卡","乐器卡","家电卡","美酒卡","建材卡","保健卡","家具卡","生鲜卡","童装卡","厨电卡"};

        ArrayList <Integer> arr = new ArrayList();
        Random r = new Random();

        int temp=0;
        for (int i = 0;i<100;i++,temp=0) {
            int num = r.nextInt(40);

            if (arr.size()<6) {
                for (int j=0 ;j<arr.size();j++) {
                    if (num == arr.get(j)){
                        temp++;
                    }
                }
                if (temp == 0) {
                    arr.add(num);
                }
            }
        }


        for (int i=0;i<5;i++) {
            System.out.println(s[arr.get(i)]);
        }

    }
}
