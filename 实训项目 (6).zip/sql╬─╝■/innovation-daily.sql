/*
 Navicat Premium Data Transfer

 Source Server         : innovation-daily
 Source Server Type    : MySQL
 Source Server Version : 50650
 Source Host           : 1.15.155.4:3306
 Source Schema         : innovation-daily

 Target Server Type    : MySQL
 Target Server Version : 50650
 File Encoding         : 65001

 Date: 09/06/2023 10:15:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for student_sign
-- ----------------------------
DROP TABLE IF EXISTS `student_sign`;
CREATE TABLE `student_sign` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户id',
  `sign_time` datetime DEFAULT NULL COMMENT '签到时间',
  `out_time` datetime DEFAULT NULL COMMENT '签退时间',
  `learn_content` varchar(255) DEFAULT NULL COMMENT '学习内容',
  `real_learn_content` varchar(255) DEFAULT NULL COMMENT '实际学习内容',
  `learn_time` bigint(255) DEFAULT NULL COMMENT '学习时长',
  `status` int(255) DEFAULT '0' COMMENT '签到为0，签过退为1',
  `create_user` bigint(255) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of student_sign
-- ----------------------------
BEGIN;
INSERT INTO `student_sign` VALUES (1, 1, '2023-06-09 10:01:06', '2023-06-09 10:01:18', 'java', 'java', 0, 8, NULL, '2023-06-09 10:01:06', NULL, '2023-06-09 10:01:18');
INSERT INTO `student_sign` VALUES (2, 1, '2023-06-09 10:01:30', '2023-06-09 10:01:54', '学习vue', 'java', 0, 8, NULL, '2023-06-09 10:01:30', NULL, '2023-06-09 10:01:54');
INSERT INTO `student_sign` VALUES (3, 1, '2023-06-09 10:01:38', '2023-06-09 10:01:58', '学习vue', 'java', 0, 8, NULL, '2023-06-09 10:01:38', NULL, '2023-06-09 10:01:58');
INSERT INTO `student_sign` VALUES (4, 1, '2023-06-09 10:01:42', '2023-06-09 10:02:02', '学习vue', 'java', 0, 8, NULL, '2023-06-09 10:01:42', NULL, '2023-06-09 10:02:02');
INSERT INTO `student_sign` VALUES (5, 1, '2023-06-09 10:01:45', '2023-06-09 10:02:05', '学习vue', 'java', 0, 8, NULL, '2023-06-09 10:01:45', NULL, '2023-06-09 10:02:05');
INSERT INTO `student_sign` VALUES (6, 1, '2023-06-09 10:01:48', NULL, '学习vue', NULL, NULL, 0, NULL, '2023-06-09 10:01:48', NULL, '2023-06-09 10:01:48');
INSERT INTO `student_sign` VALUES (7, 1, '2023-06-09 10:03:30', NULL, '学习es6', NULL, NULL, 0, NULL, '2023-06-09 10:03:30', NULL, '2023-06-09 10:03:30');
INSERT INTO `student_sign` VALUES (8, 1, '2023-06-09 10:04:05', NULL, '学习es6', NULL, NULL, 0, NULL, '2023-06-09 10:04:05', NULL, '2023-06-09 10:04:05');
COMMIT;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `code` varchar(255) DEFAULT NULL COMMENT '编号',
  `username` varchar(255) DEFAULT NULL COMMENT '学生姓名',
  `password` varchar(255) DEFAULT NULL COMMENT '密码',
  `stu_class` varchar(255) DEFAULT NULL COMMENT '班级',
  `learn_direction` varchar(255) DEFAULT NULL COMMENT '学习方向',
  `status` int(255) DEFAULT '0' COMMENT '0为普通用户/1为管理员',
  `out_flag` int(255) DEFAULT '0' COMMENT '是否退出小组，0为否，1为是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user
-- ----------------------------
BEGIN;
INSERT INTO `user` VALUES (1, '666666', '111', '111', '计科211', '全栈', 0, 0);
INSERT INTO `user` VALUES (2, '153761', '杨小安', '12346', NULL, NULL, 0, 0);
INSERT INTO `user` VALUES (3, '210515', 'sai', '123', NULL, NULL, 0, 0);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
