/*
 Navicat Premium Data Transfer

 Source Server         : 本机
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : 127.0.0.1:3306
 Source Schema         : db1

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 09/06/2023 10:17:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for mywork
-- ----------------------------
DROP TABLE IF EXISTS `mywork`;
CREATE TABLE `mywork`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `memcount` int(11) DEFAULT NULL,
  `resname` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `settime` date NOT NULL,
  `active` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE,
  UNIQUE INDEX `resname`(`resname`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mywork
-- ----------------------------
INSERT INTO `mywork` VALUES (1, '德云社', 300, '郭德纲', '德云社是一个相声团体', '1976-01-01', '周三晚上19点30分');
INSERT INTO `mywork` VALUES (2, '足球社', 20, '张三', '足球社是一个团结的大团体', '2023-06-06', '周二下午15点');
INSERT INTO `mywork` VALUES (3, '篮球社', 61, '李四', '篮球社是一个致力于打篮球的团体', '2023-06-07', '周一下午14点');
INSERT INTO `mywork` VALUES (7, '醒来折花', 5, '奥德彪', '阿德萨瓦大撒的哇大苏打', '2023-06-08', '周一下午四点');

SET FOREIGN_KEY_CHECKS = 1;
