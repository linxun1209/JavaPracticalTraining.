package com.web;

import com.pojo.mywork;
import com.service.myworkService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Date;

/**
 * 此servlet是为了响应增加按钮而设置
 */
@WebServlet("/addServlet")
public class AddServlet extends HttpServlet {
    private myworkService service=new myworkService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");

        //接受表单提交的数据
        String name = request.getParameter("name");
        String memcount = request.getParameter("memcount");
        String resname = request.getParameter("resname");
        String description = request.getParameter("description");
        String settime = request.getParameter("settime");
        String active = request.getParameter("active");

        //封装为一个mywork对象
        mywork mywork= new mywork();
        mywork.setName(name);
        mywork.setMemcount(Integer.parseInt(memcount));
        mywork.setResname(resname);
        mywork.setDescription(description);
        mywork.setSettime(Date.valueOf(settime));
        mywork.setActive(active);

        //调用service完成添加
        service.add(mywork);

        //转发到selectAllServlet中
        request.getRequestDispatcher("/selectAllServlet").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
