package com.web;

import com.pojo.mywork;
import com.service.myworkService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

/**
 * 此servlet是为了调出被删除的信息，是操作者确认是否删除
 */
@WebServlet("/preDeleteServlet")
public class PreDeleteServlet extends HttpServlet {
    private myworkService service=new myworkService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取id
        String id = request.getParameter("id");
        //调用service查询
        mywork mywork = service.selectById(Integer.parseInt(id));
        //存储到request
        request.setAttribute("mywork",mywork);
        //转发到predelete.jsp
        request.getRequestDispatcher("/predelete.jsp").forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
