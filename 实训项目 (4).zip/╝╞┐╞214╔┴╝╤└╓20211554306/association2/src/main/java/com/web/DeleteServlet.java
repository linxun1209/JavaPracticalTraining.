package com.web;

import com.pojo.mywork;
import com.service.myworkService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

/**
 * 此servlet是为了删除而设置
 */
@WebServlet("/deleteServlet")
public class DeleteServlet extends HttpServlet {
    private myworkService service=new myworkService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取id
        String id = request.getParameter("id");

        //调用service查询id
        mywork mywork = service.selectById(Integer.parseInt(id));

        //调用方法
        service.delete(mywork);

        //转发到selectAllServlet
        request.getRequestDispatcher("/selectAllServlet").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
