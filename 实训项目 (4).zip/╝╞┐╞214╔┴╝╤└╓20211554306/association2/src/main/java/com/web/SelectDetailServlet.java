package com.web;

import com.pojo.mywork;
import com.service.myworkService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

/**
 * 此servlet是为了是操作者查看更详细的信息
 */
@WebServlet("/selectDetailServlet")
public class SelectDetailServlet extends HttpServlet {
    private myworkService service=new myworkService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取id
        String id = request.getParameter("id");
        //调用service查询
        mywork mywork = service.selectById(Integer.parseInt(id));
        //存储到request中
        request.setAttribute("mywork",mywork);
        //转发到detail.jsp中
        request.getRequestDispatcher("/detail.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
