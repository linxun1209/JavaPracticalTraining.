package com.web;

import com.mysql.jdbc.StringUtils;
import com.pojo.mywork;
import com.service.myworkService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/selectByRandomServlet")
public class SelectByRandomServlet extends HttpServlet {
    private myworkService service=new myworkService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String name = request.getParameter("name");
        String resname = request.getParameter("resname");
        String str="";
        int num=0;
        if(!StringUtils.isNullOrEmpty(name)){
            str+="name like '%"+name+"%'";
            num++;
        }
        if(!StringUtils.isNullOrEmpty(resname)){
            if(num!=0){
                str+="and ";
            }
            str+="resname like '%"+resname+"%'";
        }
        str+=";";
        List<mywork> myworks=service.selectByrandom(str);
        request.setAttribute("myworks",myworks);
        request.getRequestDispatcher("/random.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
