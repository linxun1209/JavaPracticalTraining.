package com.web;

import com.pojo.mywork;
import com.service.myworkService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/updateServlet")
public class UpdateServlet extends HttpServlet {
    private myworkService service=new myworkService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        //接受表单的数据
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String memcount = request.getParameter("memcount");
        String resname = request.getParameter("resname");
        String description = request.getParameter("description");
        String settime = request.getParameter("settime");
        String active = request.getParameter("active");
        //转换时间
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        Date setParsedTime=null;
        try {
            setParsedTime = sdf.parse(settime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //todo:用户输入不合法值为做校验

        //封装为一个mywork对象
        mywork mywork = new mywork();
        mywork.setId(Integer.parseInt(id));
        mywork.setName(name);
        mywork.setMemcount(Integer.parseInt(memcount));
        mywork.setResname(resname);
        mywork.setDescription(description);
        mywork.setSettime(setParsedTime);
        mywork.setActive(active);
        //调用方法
        service.update(mywork);
        //转发到SelectAllServlet
        request.getRequestDispatcher("/selectAllServlet").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
