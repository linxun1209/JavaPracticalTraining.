package com.mapper;

import com.pojo.mywork;
import org.apache.ibatis.annotations.*;

import java.util.Date;
import java.util.List;

@Mapper
public interface myworkMapper {
    /**
     *查询所有
     * @return
    */
    @Select("select * from mywork")
    List<mywork> sellectAll();

    /**
     *添加信息
     * @para mywork
     */
    @Insert("insert into mywork values (null,#{name},#{memcount},#{resname},#{description},#{settime},#{active})")
    void add(mywork mywork);

    /**
     *查看详细，根据id查询
     * @return
     */
    @Select("select * from mywork where id=#{id}")
    mywork selectById(int id);

    /**
     * 删除
     * @param mywork
     */
    @Delete("delete from mywork where id=#{id};")
    void delete(mywork mywork);

    /**
     * 修改
     * @param mywork
     * @return
     */
    @Update("update mywork set name=#{name},memcount=#{memcount},resname=#{resname},description=#{description},settime=#{settime},active=#{active}where id=#{id}")
    void update(mywork mywork);

    /**
     *条件查询
     * @return
     */
    @Select("select * from mywork where ${sql}")
    List<mywork> selectByrandom(@Param("sql")String sql);

    /**
     * 按社团编号查询
     * @return
     */
    @Select("select * from mywork where id=#{id}")
    List<mywork> selectById2(int id);

    /**
     * 按社团人数查询
     * @return
     */
    @Select("select * from mywork where memcount=#{memcount}")
    List<mywork> selectByMemcount(int memcount);

    /**
     * 按社团成立时间查询
     * @return
     */
    @Select("select * from mywork where settime=#{settime}")
    List<mywork> selectBySettime(Date settime);
}
