package com.pojo;

import java.util.Date;

public class mywork {
    private Integer id;
    private String name;
    private Integer memcount;
    private String resname;
    private String description;
    private Date settime;
    private String active;

    @Override
    public String toString() {
        return "mywork{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", memcount=" + memcount +
                ", resname='" + resname + '\'' +
                ", description='" + description + '\'' +
                ", settime=" + settime +
                ", active='" + active + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMemcount() {
        return memcount;
    }

    public void setMemcount(Integer memcount) {
        this.memcount = memcount;
    }

    public String getResname() {
        return resname;
    }

    public void setResname(String resname) {
        this.resname = resname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getSettime() {
        return settime;
    }

    public void setSettime(Date settime) {
        this.settime = settime;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }
}
