package com.service;


import com.mapper.myworkMapper;
import com.pojo.mywork;
import com.utils.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import javax.sql.DataSource;
import java.sql.Date;
import java.util.List;

public class myworkService {
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();
    /**
    * 查询所有
    * @return
    */
    public List<mywork> selectAll(){
        //获取SqlSession对象
        SqlSession sqlSession = factory.openSession();
        //获取mapper对象
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        //调用mapper中的方法
        List<mywork> myworks = mapper.sellectAll();
        //释放资源
        sqlSession.close();
        //返回List集合对象
        return myworks;
    }

    /**
     *查看详细,根据id查询
     */
    public mywork selectById(int id){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        mywork mywork = mapper.selectById(id);
        sqlSession.close();
        return mywork;
    }

    /**
     * 添加信息
     * @param mywork
     */
    public void add(mywork mywork){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        mapper.add(mywork);
        sqlSession.commit();
        sqlSession.close();
    }

    /**
     * 删除
     * @param mywork
     */
    public void delete (mywork mywork){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        mapper.delete(mywork);
        sqlSession.commit();
        sqlSession.close();
    }

    /**
     * 修改信息
     * @param mywork
     * @return
     */
    public void update(mywork mywork){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        mapper.update(mywork);
        sqlSession.commit();
        sqlSession.close();
    }

    /**
     *条件查询
     * @param sql
     * @return
     */
    public List<mywork> selectByrandom(String sql){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        List<mywork> myworks = mapper.selectByrandom(sql);
        sqlSession.close();
        return myworks;
    }

    /**
     * 按社团编号查询
     * @return
     */
    public List<mywork> selectById2 (int id){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        List<mywork> myworks = mapper.selectById2(id);
        sqlSession.close();
        return myworks;
    }

    /**
     * 按社团人数查询
     * @return
     */
    public List<mywork> selectByMemcount(int memcount){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        List<mywork> myworks = mapper.selectByMemcount(memcount);
        sqlSession.close();
        return myworks;
    }

    /**
     * 按社团成立时间查询
     * @return
     */
    public List<mywork> selectBySettime (Date settime){
        SqlSession sqlSession = factory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        List<mywork> myworks = mapper.selectBySettime(settime);
        sqlSession.close();
        return myworks;
    }
}
