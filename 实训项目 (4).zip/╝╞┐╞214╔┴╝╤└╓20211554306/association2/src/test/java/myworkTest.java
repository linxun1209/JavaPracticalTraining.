import com.mapper.myworkMapper;
import com.pojo.mywork;
import com.utils.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

public class myworkTest {
    @Test
    public void testSelectAll()throws IOException{
        SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        myworkMapper mapper = sqlSession.getMapper(myworkMapper.class);
        List<mywork> myworks = mapper.sellectAll();
        System.out.println(myworks);
        sqlSession.close();
    }
}
