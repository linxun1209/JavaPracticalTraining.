package model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/12 0012 20:57
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {
    private String studentNo;//学号
    private String name; //姓名
    private String sex; //性别
    private int age; //年龄
    private String banji; //班级
    private String bornDate; //出生日期
    private String phone; //电话
    private String major; //专业
    private String faculty;//院系
    private String address; //地址

}

