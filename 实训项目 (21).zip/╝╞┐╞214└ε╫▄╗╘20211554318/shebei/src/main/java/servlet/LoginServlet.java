package servlet; /**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/12 0012 20:58
 * @Description:${description}
 */

import dao.UserDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "LoginServlet", value = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        UserDao userDao = new UserDao();
        boolean checker = userDao.login(username, password);
        if (checker) {
            request.getRequestDispatcher("StudentServlet").forward(request, response);
            request.getSession().setAttribute("message", "登录成功！");
        } else {
            request.getRequestDispatcher("login.jsp").forward(request, response);
            request.getSession().setAttribute("message", "登录失败！");
        }
    }
}

