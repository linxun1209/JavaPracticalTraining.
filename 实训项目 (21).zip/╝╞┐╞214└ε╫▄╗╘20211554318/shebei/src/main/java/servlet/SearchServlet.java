package servlet; /**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/15 0015 18:17
 * @Description:${description}
 */

import dao.StudentDao;
import model.Student;


import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "SearchServlet", value = "/SearchServlet")
public class SearchServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            //设置请求编码格式
            request.setCharacterEncoding("utf-8");
            //设置响应类别
            response.setContentType("text/html;charset=utf-8");
            String studentNo = request.getParameter("studentNo");
            String name = request.getParameter("name");
            StudentDao studentDao = new StudentDao();
            List<Student> studentList = studentDao.searchStudent(studentNo, name);
            request.setAttribute("studentList", studentList);
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
