package servlet; /**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/13 0013 21:49
 * @Description:${description}
 */

import dao.StudentDao;
import model.Student;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "SelectByStudentNoServlet", value = "/SelectByStudentNoServlet")
public class SelectByStudentNoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置请求编码格式
        request.setCharacterEncoding("utf-8");
        //设置响应类别
        response.setContentType("text/html;charset=utf-8");
        String studentNo = request.getParameter("studentNo");
        StudentDao studentDao = new StudentDao();
        Student student = studentDao.selectByStudentNo(studentNo);
        request.setAttribute("student", student);
        request.getRequestDispatcher("selectByStudentNo.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
