package servlet; /**
 * -*- coding: utf-8 -*-
 *
 * @Author: LZN
 * @Date: 2023/3/13 0013 13:17
 * @Description:${description}
 */

import dao.StudentDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "DeleteStudentServlet", value = "/DeleteStudentServlet")
public class DeleteStudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentNo = req.getParameter("studentNo");
        if (studentNo != null && !studentNo.equals("")) {
            StudentDao studentDao = new StudentDao();
            studentDao.deleteStudent(studentNo);
        }
        req.getRequestDispatcher("StudentServlet").forward(req, resp);
    }
}
