-- auto-generated definition
create schema `j2ee-studentinfor`;
create table shebei
(
    address  varchar(10) null comment '数量',
    faculty  varchar(20) null comment '保修时间',
    major    varchar(10) null comment '是否损坏',
    phone    varchar(20) null comment '厂家名称',
    bornDate date        null comment '购买日期',
    xinghao  varchar(10) null comment '型号',
    age      int         null comment '数量',
    sex      varchar(10) null comment '设备状态',
    name     varchar(10) null comment '设备名称',
    bianhao  varchar(20) not null comment '设备编号'
        primary key
);
insert into shebei (address, faculty, major, phone, bornDate, xinghao, age, sex, name, bianhao) values ('3', '3个月', '否', '化为', '2023-06-01', '化为-1', 1000, '正常', '键盘', '12');
insert into shebei (address, faculty, major, phone, bornDate, xinghao, age, sex, name, bianhao) values ('2', '1年', '否', '虾米', '2023-06-02', '虾米-2', 500, '正常', '鼠标', '3');
insert into shebei (address, faculty, major, phone, bornDate, xinghao, age, sex, name, bianhao) values ('4', '2年', '否', '猕猴油', '2023-06-06', '米忽悠-5', 2000, '正常', '投影仪', '5');


-- auto-generated definition
create table user
(
    id       int auto_increment
        primary key,
    username varchar(20) null,
    password varchar(16) null

)
    charset = utf8mb3;
    insert into user (id, username, password) values (4, 'admin', '123');
insert into user (id, username, password) values (5, 'admin', '123');
insert into user (id, username, password) values (6, 'lzn', '1');
insert into user (id, username, password) values (7, '杜纪豪', '123456');


