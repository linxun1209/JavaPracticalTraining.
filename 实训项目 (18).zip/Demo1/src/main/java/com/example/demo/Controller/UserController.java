package com.example.demo.Controller;

import com.example.demo.Pojo.Result;
import com.example.demo.Pojo.user;
import com.example.demo.Server.UserServer;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.jdbc.Null;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.*;

import javax.mail.internet.MimeMessage;
import java.util.Date;
import java.util.Random;

@Api(tags = "用户")
@RestController
@RequestMapping(value = "/user",produces = {"application/json;charset=UTF-8"})
public class UserController {
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private UserServer userServer;
    @Autowired
    private RedisTemplate<String,String> template;
    @ApiOperation(value = "获取验证码")
    @GetMapping ("/email")
    public void email(@RequestParam(value = "email") String email) throws Exception {
        Random r = new Random();
        System.out.println(email);
        String value = String.valueOf(r.nextInt(8999) + 1000);
        ValueOperations<String,String> redisString = template.opsForValue();
        redisString.set(email,value,60);
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage,true);
        helper.setText(value);
        helper.setSubject("邮箱验证码");
        helper.setFrom("3400164864@qq.com");
        helper.setTo(email);
        helper.setSentDate(new Date());
        javaMailSender.send(mimeMessage);
    }

    @ApiOperation(value = "注册")
    @PostMapping("/register")
    public String register(@RequestBody user user,@RequestBody String yzm){
        ValueOperations<String,String> redisString = template.opsForValue();
        if (!redisString.get(user.getUserName()).equals(yzm)){
            return "验证码错误!";
        }
        if (userServer.register(user)){
            return "注册成功!";
        }
        return "注册失败!";
    }
    @ApiOperation(value = "登录")
    @PostMapping("login")
    public Result<Null> login(@RequestParam String yzm,@RequestParam String userName,@RequestParam String passWord){
        ValueOperations<String,String> redisString = template.opsForValue();
       if (!redisString.get(userName).equals(yzm)){
           return new Result<>(500,"验证码错误或已失效!");
       }
       if (userServer.login(userName,passWord)){
           return new Result<>(200,"登录成功!");
       }return new Result<>(500,"请确认密码或用户名是否正确!");
    }
}
