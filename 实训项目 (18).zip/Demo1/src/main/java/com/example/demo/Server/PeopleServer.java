package com.example.demo.Server;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.Pojo.people;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.events.Event;

import java.util.List;

public interface PeopleServer {
    boolean insertmsg(people people);
    boolean update(people people);
    Page<people> selectAll(int a,int b);
    List<people> selectByName(String name);
    List<people> selectByaddrise(String addrise);
    List<people> selectByage(int age);
    boolean delect(int id);
    Page<people> select(int a,int b,String string);
}
