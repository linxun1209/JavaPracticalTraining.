package com.example.demo.Pojo;


public class Result<T> {
    private int code;
    private String msg;
    private T date = null;

    public Result(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Result(int code, String msg, T date) {
        this.code = code;
        this.msg = msg;
        this.date = date;
    }
}
