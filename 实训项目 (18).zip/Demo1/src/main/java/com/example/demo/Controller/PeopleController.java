package com.example.demo.Controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.Pojo.people;
import com.example.demo.Server.PeopleServer;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "老人信息")
@RestController
@RequestMapping(value = "/people",produces = {"application/json;charset=UTF-8"})
public class PeopleController {

    @Autowired
    @Qualifier("PeopleServerimpl")
    PeopleServer peopleServer;
    /**
     * 添加老人信息
     * @param
     * @return
     */

    @ApiOperation(value = "插入老人信息")
    @PostMapping()
    public String insert(@RequestBody people people){
        if (peopleServer.insertmsg(people)){
            return "插入成功!";
        }else {
            return "插入信息失败!";
        }
    }

    /**
     * 按照id删除老人信息
     * @param id
     * @return
     */
    @ApiOperation(value = "删除老人信息")
    @GetMapping("/delect")
    public String delect(@RequestParam("id") int id ){
        if (peopleServer.delect(id)){
            return "删除成功!";
        }else {
            return "删除失败!";
        }
    }

    /**
     * 查询所有老人信息
     * @return
     */
    @ApiOperation(value = "查询所有信息")
    @GetMapping()
    public Page<people> selectAll(@RequestParam(value = "pageNo") int pageNo,
                                  @RequestParam(value = "size",required = false,defaultValue = "10")int size){
        return peopleServer.selectAll(pageNo,size);
    }

    /**
     * 修改老人信息
     * @param people
     * @return
     */
    @ApiOperation(value = "更新信息")
    @PostMapping("updata")
    public String updata(@RequestBody people people){
        if (peopleServer.update(people)){
            return "修改成功!";
        }else {
            return "修改失败!";
        }
    }

    /**
     * 根据年龄查询获奖信息
     * @param age
     * @return
     */
    @ApiOperation(value = "根据年龄查询信息")
    @GetMapping("selectByage")
    public List<people> selectByno(@RequestParam("age") int age){
        return peopleServer.selectByage(age);
    }

    /**
     * 根据姓名查询获奖信息
     * @param Name
     * @return
     */
    @ApiOperation(value = "根据姓名查询")
    @GetMapping("selectByName")
    public List<people> selectByclass(@RequestParam("Name") String Name){
        return peopleServer.selectByName(Name);
    }

    /**
     * 按照地址查询
     * @param addRise
     * @return
     */
    @ApiOperation(value = "根据地址查询")
    @GetMapping("selectByaddRise")
    public List<people> selectByawardName(@RequestParam("addRise") String addRise){
        return peopleServer.selectByaddrise(addRise);
    }

    @ApiOperation(value = "查询")
    @GetMapping("select")
    public Page<people> select(@RequestParam(value = "no") int no,
                               @RequestParam(value = "size",defaultValue = "10",required = false) int size,
                               @RequestParam(value = "query") String query){
        return peopleServer.select(no,size,query);
    }
}
