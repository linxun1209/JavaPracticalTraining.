package com.example.demo.Server.Impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.Mapper.UserMapper;
import com.example.demo.Pojo.user;
import com.example.demo.Server.UserServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("UserServerimpl")
public class UserServerimpl implements UserServer {
    @Autowired
    UserMapper userMapper;
    @Override
    public boolean register(user user) {

        return userMapper.insert(user) != 0;
    }



    @Override
    public boolean login(String passWord,String userName) {
        LambdaQueryWrapper<user> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(user::getUserName,userName);
        user user = userMapper.selectOne(lambdaQueryWrapper);
        if (user.getPassWord() == passWord)return true;
        return false;
    }
}
