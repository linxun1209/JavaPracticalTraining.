package com.example.demo.Server.Impl;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.Mapper.PeoPleMapper;
import com.example.demo.Pojo.people;
import com.example.demo.Server.PeopleServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("PeopleServerimpl")
public class PeopleServerimpl implements PeopleServer {

    @Autowired
    private PeoPleMapper peoPleMapper;

    @Override
    public boolean insertmsg(people people) {
        return peoPleMapper.insert(people) != 0;
    }

    @Override
    public boolean update(people people) {
        return peoPleMapper.updateById(people) != 0;
    }

    @Override
    public Page<people> selectAll(int a,int b) {
        Page<people> peoplePage = new Page<>(a,b);
        return peoPleMapper.selectPage(peoplePage,null);
    }

    @Override
    public List<people> selectByName(String name) {
        LambdaQueryWrapper<people> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(people::getName,name);
        return peoPleMapper.selectList(lambdaQueryWrapper);
    }

    @Override
    public List<people> selectByaddrise(String addrise) {
        LambdaQueryWrapper<people> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(people::getAddrise,addrise);
        return peoPleMapper.selectList(lambdaQueryWrapper);
    }

    @Override
    public List<people> selectByage(int age) {
        LambdaQueryWrapper<people> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(people::getName,age);
        return peoPleMapper.selectList(lambdaQueryWrapper);
    }

    @Override
    public boolean delect(int id) {
        return peoPleMapper.deleteById(id) != 0;
    }

    @Override
    public Page<people> select(int a, int b,String string) {
        Page<people> peoplePage = new Page<>(a,b);
        LambdaQueryWrapper<people> lambda= new LambdaQueryWrapper<>();
        lambda.like(people::getName,string).or().like(people::getTel,string).or().like(people::getAddrise,string);
        return peoPleMapper.selectPage(peoplePage,lambda);
    }
}
