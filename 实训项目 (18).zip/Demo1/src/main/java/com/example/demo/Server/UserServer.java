package com.example.demo.Server;

import com.example.demo.Pojo.user;


public interface UserServer {

     boolean register(user user);
     boolean login(String userName,String passWord);

}
