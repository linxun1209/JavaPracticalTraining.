import requests from "./request";

export const getAllPeople = async (data) =>
  requests({
    url: "/people",
    method: "GET",
    params: data,
  });

export const addPeople = async (data) =>
  requests({
    url: "/people",
    method: "POST",
    data: data,
  });

export const delPeople = async (data) =>
  requests({
    url: "/people/delect",
    method: "GET",
    params: data,
  });

export const updataPeople = async (data) =>
  requests({
    url: "/people/updata",
    method: "POST",
    data: data,
  });

export const searchPeople = async (data) =>
  requests({
    url: "/people/select",
    method: "GET",
    params: data,
  });

export const getCodeApi = async (data) =>
  requests({
    url: "/user/email",
    method: "GET",
    params: data,
  });

export const login = async (data) =>
  requests({
    url: "/user/login",
    method: "POST",
    params: data,
  });
