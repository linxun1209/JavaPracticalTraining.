import VueRouter from "vue-router";
import myLogin from "@/pages/login";
import addOld from "@/pages/add";

import oldManagement from "@/pages/oldManagement";
// 创建一个路由器
const router = new VueRouter({
  routes: [
    {
      path: "/login",
      component: myLogin,
      meta: {
        title: "登录",
      },
    },
    {
      path: "/addOld",
      component: addOld,
      meta: {
        title: "添加老人",
      },
    },
    {
      path: "/oldManagement",
      component: oldManagement,
      meta: {
        title: "老人管理",
      },
    },
  ],
});
//路由守卫
// 添加标题
router.afterEach((to) => {
  if (to.meta.title) {
    document.title = to.meta.title;
  }
});
export default router;
