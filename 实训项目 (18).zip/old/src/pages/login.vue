<template>
  <div class="container">
    <div class="center">
      <div class="header">登录</div>
      <el-form
        ref="form"
        :model="form"
        label-width="80px"
        style="width: 80%; text-align: center"
      >
        <el-form-item label="邮箱">
          <el-input v-model="form.name" placeholder="请输入邮箱"></el-input>
        </el-form-item>
        <el-form-item label="密码">
          <el-input
            v-model="form.password"
            placeholder="请输入密码"
            show-password
          ></el-input>
        </el-form-item>
        <el-form-item label="验证码">
          <div style="display: flex">
            <el-input v-model="form.code" placeholder="验证码"></el-input>
            <el-button
              style="margin-left: 10px"
              @click="getCode"
              :disabled="isDis"
              >{{ msg }}</el-button
            >
          </div>
        </el-form-item>
        <el-form-item label="图像验证">
          <div style="display: flex">
            <el-input placeholder="验证码" v-model="imgCode"></el-input>
            <img
              class="myImg"
              @click="
                index++;
                index = index % 3;
              "
              :src="imgList[index].path"
              alt=""
            />
          </div>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import first from "@/assets/01.png";
import second from "@/assets/02.png";
import third from "@/assets/03.png";
import { getCodeApi, login } from "@/api/user";

export default {
  name: "myLogin",
  data() {
    return {
      form: {
        name: "",
        password: "",
        code: "",
      },
      isDis: false,
      msg: "获取验证码",
      timier: null,
      countdown: 60,
      index: 0,
      imgCode: "",
      imgList: [
        {
          path: first,
          code: "2907",
        },
        {
          path: second,
          code: "7364",
        },
        {
          path: third,
          code: "c338",
        },
      ],
    };
  },
  methods: {
    onSubmit() {
      console.log("submit!");
      if (this.imgCode !== this.imgList[this.index].code) {
        this.$message({
          message: "请输入正确的图像验证码",
          type: "warning",
        });
        return;
      }
      login({
        passWord: this.form.password,
        userName: this.form.name,
        yzm: this.form.code,
      }).then((res) => {
        console.log(res);
        this.$router.push("/addOld");
      });
    },
    getCode() {
      this.isDis = true;
      getCodeApi({
        email: this.form.name,
      }).then((res) => {
        console.log(res);
      });
      this.timier = setInterval(() => {
        this.msg = `${this.countdown--}s后重新获取`;
        if (this.countdown <= 0) {
          clearInterval(this.timier);
          this.isDis = false;
          this.countdown = 60;
          this.msg = "获取验证码";
        }
      }, 1000);
    },
  },
};
</script>

<style scoped>
.container {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: rgba(0, 0, 0, 0.6);
}

.center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 500px;
  height: 400px;
  background-color: white;
  padding: 20px 50px;
  box-sizing: border-box;
}

.header {
  padding: 20px;
  text-align: center;
  font-size: 20px;
  font-weight: bold;
}

.myImg {
  margin-left: 10px;
  width: 100px;
  height: 40px;
  background-size: cover;
}
</style>
