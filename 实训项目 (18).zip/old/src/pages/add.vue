<template>
  <div class="container">
    <div class="center">
      <div class="header">
        <el-button @click="jump()">老人管理</el-button>
      </div>
      <el-form ref="form" :model="form" label-width="100px">
        <el-form-item label="老人姓名">
          <el-input v-model="form.name" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="亲属电话:">
          <el-input v-model="form.tel" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="家庭住址:">
          <el-input v-model="form.addrise" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item label="年龄:">
          <el-input-number
            v-model="form.age"
            :min="1"
            :max="120"
            label="描述文字"
          ></el-input-number>
        </el-form-item>
        <el-form-item label="老人费用(k):">
          <el-input-number
            v-model="form.cost"
            :min="1"
            :max="120"
            label="描述文字"
          ></el-input-number>
        </el-form-item>
        <el-form-item label="备注">
          <el-input
            type="textarea"
            v-model="form.remarks"
            placeholder="请输入备注"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">{{
            $route.query.id ? "修改" : "增加"
          }}</el-button>
          <el-button @click="jump()">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import { Radio, TimePicker, RadioGroup, InputNumber } from "element-ui";
import { addPeople, updataPeople } from "@/api/user";
export default {
  name: "addOld",
  components: {
    [Radio.name]: Radio,
    [TimePicker.name]: TimePicker,
    [RadioGroup.name]: RadioGroup,
    [InputNumber.name]: InputNumber,
  },
  data() {
    return {
      form: {
        name: "",
        remarks: "",
        age: 10,
        cost: 0,
        tel: "",
        addrise: "",
      },
    };
  },
  methods: {
    onSubmit() {
      if (this.$route.query.id) {
        // 修改
        updataPeople({ ...this.form, id: this.$route.query.id })
          .then((res) => {
            console.log(res);
            this.jump();
          })
          .catch((err) => {
            console.log(err);
          });
        return;
      }
      addPeople(this.form)
        .then((res) => {
          console.log(res);
          this.form = {
            name: "",
            desc: "",
            age: 10,
            cost: 0,
            tel: "",
            address: "",
          };
        })
        .catch((err) => {
          console.log(err);
        });
    },
    jump() {
      this.$router.push("/oldManagement");
    },
  },
  mounted() {
    if (this.$route.query.id) {
      this.form = JSON.parse(localStorage.getItem("userInfo"));
    }
  },
};
</script>
<style scoped>
.container {
  margin-top: 30px;
}
.center {
  max-width: 1200px;
  margin: 0 auto;
}

.header {
  margin-bottom: 20px;
}
</style>
