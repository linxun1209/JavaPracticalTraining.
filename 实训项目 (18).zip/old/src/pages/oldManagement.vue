<template>
  <div class="container">
    <div class="header">
      <el-button @click="addOld()">添加老人</el-button>
      <div class="" style="margin: 20px 0px 0px 0px">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="地址/年龄/姓名:">
            <el-input
              v-model="formInline.query"
              placeholder="地址/年龄/姓名"
              clearable
            ></el-input>
          </el-form-item>
          <el-button type="primary" @click="searchPeopleFn">搜索</el-button>
          <el-button @click="getPeopleInfo">重置</el-button>
        </el-form>
      </div>
    </div>
    <el-table :data="tableData" border style="width: 100%">
      <el-table-column prop="name" label="姓名" width="180"> </el-table-column>
      <el-table-column prop="addrise" label="地址"> </el-table-column>
      <el-table-column prop="age" label="年龄" width="180"> </el-table-column>
      <el-table-column prop="tel" label="电话" width="180"> </el-table-column>
      <el-table-column prop="cost" label="费用(k)" width="180">
      </el-table-column>
      <el-table-column prop="remarks" label="备注" width="180">
      </el-table-column>

      <el-table-column label="操作" width="100">
        <template slot-scope="scope">
          <el-button @click="handleDel(scope.row)" type="text" size="small"
            >删除</el-button
          >
          <el-button type="text" size="small" @click="handleReg(scope.row)"
            >编辑</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <div style="margin: 0px 0px 20px 0px"></div>
    <el-pagination
      v-if="isShow"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[5, 10, 15, 20]"
      :page-size="10"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    >
    </el-pagination>
  </div>
</template>

<script>
import { InputNumber } from "element-ui";
import { getAllPeople, delPeople, searchPeople } from "@/api/user";
export default {
  name: "oldManagement",
  data() {
    return {
      tableData: [],
      currentPage: 1,
      total: 0,
      pageNo: 1,
      size: 10,
      formInline: {
        query: "",
      },
      isShow: true,
    };
  },
  components: {
    [InputNumber.name]: InputNumber,
  },
  methods: {
    searchPeopleFn() {
      this.isShow = false;
      searchPeople({
        no: 1,
        query: this.formInline.query,
        size: 1,
      })
        .then((res) => {
          return searchPeople({
            no: 1,
            query: this.formInline.query,
            size: res.total,
          });
        })
        .then((res) => {
          this.tableData = res.records;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    addOld() {
      this.$router.push("/addOld");
    },
    handleDel(item) {
      this.$confirm("此操作将永久删除, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          return delPeople({ id: item.id });
        })
        .then((res) => {
          console.log(res);
          if (this.formInline.query) {
            this.searchPeopleFn();
            return;
          }
          this.getPeopleInfo();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    handleReg(item) {
      console.log(item);
      localStorage.setItem("userInfo", JSON.stringify(item));
      this.$router.push({
        path: "/addOld",
        query: {
          id: item.id,
        },
      });
    },
    getPeopleInfo() {
      this.isShow = true;
      this.formInline.query = "";
      getAllPeople({
        pageNo: this.pageNo,
        size: this.size,
      })
        .then((res) => {
          this.total = res.total;
          this.tableData = res.records;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    handleSizeChange(val) {
      this.size = val;
      this.getPeopleInfo();
    },
    handleCurrentChange(val) {
      this.pageNo = val;
      this.getPeopleInfo();
    },
  },
  mounted() {
    this.getPeopleInfo();
  },
};
</script>

<style scoped>
.header {
  margin-bottom: 30px;
}
.container {
  padding: 20px 50px;
}
</style>
